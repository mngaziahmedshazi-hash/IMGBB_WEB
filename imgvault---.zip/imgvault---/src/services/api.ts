import { User, ImageRecord, ImgBBApiResponse } from '../types/index.ts';

const TOKEN_STORAGE_KEY = 'imgvault_auth_token';

export const authStorage = {
  getToken(): string | null {
    return localStorage.getItem(TOKEN_STORAGE_KEY);
  },
  setToken(token: string) {
    localStorage.setItem(TOKEN_STORAGE_KEY, token);
  },
  clearToken() {
    localStorage.removeItem(TOKEN_STORAGE_KEY);
  },
};

function getHeaders(extraHeaders: Record<string, string> = {}): HeadersInit {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...extraHeaders,
  };
  const token = authStorage.getToken();
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

export const api = {
  async register(name: string, email: string, password: string): Promise<{ user: User; token: string }> {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to register.');
    authStorage.setToken(data.token);
    return data;
  },

  async login(email: string, password: string): Promise<{ user: User; token: string }> {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to log in.');
    authStorage.setToken(data.token);
    return data;
  },

  async getCurrentUser(): Promise<User | null> {
    const token = authStorage.getToken();
    if (!token) return null;
    try {
      const res = await fetch('/api/auth/me', {
        headers: getHeaders(),
      });
      if (!res.ok) {
        authStorage.clearToken();
        return null;
      }
      const data = await res.json();
      return data.user;
    } catch {
      return null;
    }
  },

  async regenerateApiKey(): Promise<string> {
    const res = await fetch('/api/auth/regenerate-key', {
      method: 'POST',
      headers: getHeaders(),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to regenerate API key');
    return data.apiKey;
  },

  logout() {
    authStorage.clearToken();
  },

  /**
   * Uploads an image using either base64 or file.
   * Directly compatible with ImgBB v1 endpoint format.
   */
  async uploadImage(
    imageDataUrl: string,
    options: {
      name?: string;
      expiration?: number;
      apiKey?: string;
    } = {}
  ): Promise<ImgBBApiResponse['data']> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    // If an API key is provided or logged in, send it
    if (options.apiKey) {
      headers['X-API-Key'] = options.apiKey;
    } else {
      const token = authStorage.getToken();
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
    }

    const payload = {
      image: imageDataUrl,
      name: options.name,
      expiration: options.expiration || 0,
      key: options.apiKey,
    };

    const res = await fetch('/api/1/upload', {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data?.error?.message || 'Upload failed. Please try again.');
    }

    return data.data;
  },

  async getImages(params: { scope?: 'all' | 'user' | 'public'; q?: string; sort?: string } = {}): Promise<any[]> {
    const query = new URLSearchParams();
    if (params.scope) query.set('scope', params.scope);
    if (params.q) query.set('q', params.q);
    if (params.sort) query.set('sort', params.sort);

    const res = await fetch(`/api/images?${query.toString()}`, {
      headers: getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load images');
    const data = await res.json();
    return data.images || [];
  },

  async getImage(id: string): Promise<any> {
    const res = await fetch(`/api/images/${id}`);
    if (!res.ok) throw new Error('Image not found');
    const data = await res.json();
    return data.image;
  },

  async deleteImage(id: string, deleteToken?: string): Promise<void> {
    const url = deleteToken ? `/api/images/${id}?token=${deleteToken}` : `/api/images/${id}`;
    const res = await fetch(url, {
      method: 'DELETE',
      headers: getHeaders(),
    });
    if (!res.ok) {
      const data = await res.json();
      throw new Error(data.error || 'Failed to delete image');
    }
  },

  async getStorageConfig(): Promise<any> {
    try {
      const res = await fetch('/api/config/providers');
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  },
};
