import { EmbedCodes, ImageRecord } from '../types/index.ts';

/**
 * Generates an ImgBB-style API key with standard prefix.
 */
export function generateApiKey(prefix = 'iv_live_'): string {
  const chars = 'abcdef0123456789';
  let randomHex = '';
  for (let i = 0; i < 32; i++) {
    randomHex += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `${prefix}${randomHex}`;
}

/**
 * Validates whether a provided API key matches the expected format.
 */
export function validateApiKey(key?: string | null): boolean {
  if (!key || typeof key !== 'string') return false;
  // Key must be at least 20 chars and start with iv_live_ or iv_test_ or be 32+ hex chars
  const trimmed = key.trim();
  if (trimmed.startsWith('iv_live_') || trimmed.startsWith('iv_test_')) {
    return trimmed.length >= 24;
  }
  return /^[a-f0-9]{32,64}$/i.test(trimmed);
}

/**
 * Human readable file size formatter.
 */
export function formatBytes(bytes: number, decimals = 1): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  const safeI = Math.min(i, sizes.length - 1);
  return `${parseFloat((bytes / Math.pow(k, safeI)).toFixed(dm))} ${sizes[safeI]}`;
}

/**
 * Generates all direct, viewer, BBCode, HTML and Markdown embed snippets.
 */
export function generateEmbedCodes(image: Pick<ImageRecord, 'id' | 'filename' | 'title' | 'mimeType' | 'storageUrl'>, baseUrl = ''): EmbedCodes {
  const origin = baseUrl ? baseUrl.replace(/\/$/, '') : (typeof window !== 'undefined' ? window.location.origin : '');
  
  // Direct image URL
  const ext = image.filename ? image.filename.split('.').pop() : 'png';
  const directUrl = image.storageUrl || `${origin}/i/${image.id}.${ext}`;
  const viewerUrl = `${origin}/view/${image.id}`;
  const title = image.title || image.filename || 'Hosted Image';

  return {
    directUrl,
    viewerUrl,
    markdown: `[![${title}](${directUrl})](${viewerUrl})`,
    bbcodeFull: `[url=${viewerUrl}][img]${directUrl}[/img][/url]`,
    bbcodeThumb: `[url=${viewerUrl}][img]${directUrl}[/img][/url]`,
    htmlFull: `<a href="${viewerUrl}" target="_blank" rel="noopener noreferrer"><img src="${directUrl}" alt="${title}" border="0" /></a>`,
    htmlThumb: `<a href="${viewerUrl}" target="_blank" rel="noopener noreferrer"><img src="${directUrl}" alt="${title}" border="0" /></a>`,
  };
}

/**
 * Calculate expiry date timestamp from duration in seconds (0 = forever).
 */
export function calculateExpiryDate(seconds: number): string | null {
  if (!seconds || seconds <= 0) return null;
  const expiryTime = Date.now() + seconds * 1000;
  return new Date(expiryTime).toISOString();
}

/**
 * Check if an image is expired based on its expiresAt timestamp.
 */
export function isExpired(expiresAt: string | null): boolean {
  if (!expiresAt) return false;
  return new Date(expiresAt).getTime() < Date.now();
}

/**
 * Validate image file format and size.
 */
export function validateImageFile(file: { type: string; size: number }, maxSizeMB = 32): { valid: boolean; error?: string } {
  const allowedMimes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml'];
  if (!allowedMimes.includes(file.type)) {
    return {
      valid: false,
      error: `Unsupported format (${file.type || 'unknown'}). Supported formats: JPG, PNG, WEBP, GIF, SVG.`
    };
  }
  const maxSizeBytes = maxSizeMB * 1024 * 1024;
  if (file.size > maxSizeBytes) {
    return {
      valid: false,
      error: `Image exceeds maximum allowed size of ${maxSizeMB} MB (${formatBytes(file.size)}).`
    };
  }
  return { valid: true };
}
