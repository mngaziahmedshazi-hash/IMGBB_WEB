import test from 'node:test';
import assert from 'node:assert/strict';
import {
  generateApiKey,
  validateApiKey,
  formatBytes,
  generateEmbedCodes,
  calculateExpiryDate,
  isExpired,
  validateImageFile,
} from './formatters.ts';

test('generateApiKey produces valid iv_live_ prefixed keys with high entropy', () => {
  const key1 = generateApiKey();
  const key2 = generateApiKey();

  assert.ok(key1.startsWith('iv_live_'));
  assert.equal(key1.length, 8 + 32); // 'iv_live_' (8) + 32 hex chars
  assert.notEqual(key1, key2);
  assert.equal(validateApiKey(key1), true);
});

test('validateApiKey rejects invalid or short keys and accepts valid ones', () => {
  assert.equal(validateApiKey(''), false);
  assert.equal(validateApiKey(null), false);
  assert.equal(validateApiKey('short'), false);
  assert.equal(validateApiKey('iv_live_short'), false);
  assert.equal(validateApiKey('iv_live_0123456789abcdef0123456789abcdef'), true);
  // Hex string 32 chars
  assert.equal(validateApiKey('0123456789abcdef0123456789abcdef'), true);
});

test('formatBytes correctly scales bytes to KB, MB, GB', () => {
  assert.equal(formatBytes(0), '0 B');
  assert.equal(formatBytes(500), '500 B');
  assert.equal(formatBytes(1024), '1 KB');
  assert.equal(formatBytes(1024 * 1024 * 2.5), '2.5 MB');
  assert.equal(formatBytes(1024 * 1024 * 1024 * 1.2), '1.2 GB');
});

test('generateEmbedCodes produces direct, viewer, bbcode, html, and markdown formats', () => {
  const mockImage = {
    id: 'test-img-123',
    filename: 'photo.jpg',
    title: 'Sunset in Mountains',
    mimeType: 'image/jpeg',
  };

  const codes = generateEmbedCodes(mockImage, 'https://example.com');

  assert.equal(codes.directUrl, 'https://example.com/i/test-img-123.jpg');
  assert.equal(codes.viewerUrl, 'https://example.com/view/test-img-123');
  assert.ok(codes.markdown.includes('https://example.com/i/test-img-123.jpg'));
  assert.ok(codes.markdown.includes('https://example.com/view/test-img-123'));
  assert.ok(codes.bbcodeFull.includes('[url=https://example.com/view/test-img-123][img]https://example.com/i/test-img-123.jpg[/img][/url]'));
  assert.ok(codes.htmlFull.includes('<a href="https://example.com/view/test-img-123"'));
  assert.ok(codes.htmlFull.includes('<img src="https://example.com/i/test-img-123.jpg"'));
});

test('calculateExpiryDate and isExpired correctly compute future expiration', () => {
  // 0 seconds means forever
  assert.equal(calculateExpiryDate(0), null);

  // 100 seconds in the future
  const futureIso = calculateExpiryDate(100);
  assert.ok(futureIso !== null);
  assert.equal(isExpired(futureIso), false);

  // Past ISO
  const pastIso = new Date(Date.now() - 50000).toISOString();
  assert.equal(isExpired(pastIso), true);
  assert.equal(isExpired(null), false);
});

test('validateImageFile validates mime type and size limits', () => {
  const validJpeg = { type: 'image/jpeg', size: 1024 * 1024 * 5 }; // 5MB
  assert.equal(validateImageFile(validJpeg).valid, true);

  const invalidType = { type: 'application/pdf', size: 1024 };
  assert.equal(validateImageFile(invalidType).valid, false);

  const oversized = { type: 'image/png', size: 1024 * 1024 * 40 }; // 40MB > 32MB
  assert.equal(validateImageFile(oversized, 32).valid, false);
});
