export interface User {
  id: string;
  email: string;
  name: string;
  apiKey: string;
  createdAt: string;
  storageUsedBytes: number;
  uploadCount: number;
  role?: 'user' | 'admin';
}

export interface ImageRecord {
  id: string;
  title: string;
  filename: string;
  mimeType: string;
  sizeBytes: number;
  width?: number;
  height?: number;
  createdAt: string;
  expiresAt: string | null; // ISO string or null for forever
  views: number;
  userId: string | null; // null for guest uploads
  userEmail?: string;
  dataUrl?: string; // stored base64 data for zero-config built-in storage
  storageUrl?: string; // external storage URL if using Cloudinary/S3
  deleteToken: string;
}

export interface EmbedCodes {
  directUrl: string;
  viewerUrl: string;
  markdown: string;
  bbcodeFull: string;
  bbcodeThumb: string;
  htmlFull: string;
  htmlThumb: string;
}

export interface ImgBBApiResponse {
  data: {
    id: string;
    title: string;
    url_viewer: string;
    url: string;
    display_url: string;
    size: number;
    time: string;
    expiration: string;
    image: {
      filename: string;
      name: string;
      mime: string;
      extension: string;
      url: string;
    };
    thumb?: {
      url: string;
    };
    delete_url: string;
  };
  success: boolean;
  status: number;
}

export interface AuthState {
  user: User | null;
  token: string | null;
}
