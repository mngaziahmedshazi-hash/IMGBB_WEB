import React, { useState } from 'react';
import { 
  Server, 
  Cloud, 
  Database, 
  ShieldCheck, 
  Copy, 
  Check, 
  ExternalLink, 
  Layers, 
  Sparkles, 
  Zap, 
  FileCode,
  CheckCircle2,
  Terminal,
  Lock
} from 'lucide-react';
import { copyToClipboard } from '../utils/clipboard.ts';

interface HostingGuideModalProps {
  onClose?: () => void;
}

export const HostingGuideModal: React.FC<HostingGuideModalProps> = () => {
  const [activeTab, setActiveTab] = useState<'deploy' | 'storage' | 'database' | 'auth_roadmap'>('deploy');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleCopy = async (text: string, id: string) => {
    await copyToClipboard(text);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const envTemplate = `# === Core Server Config ===
PORT=3000
NODE_ENV=production
APP_URL=https://your-app-name.onrender.com

# === Free Cloud Storage (Choose one: Cloudinary or Firebase) ===
# 1. Cloudinary Free Tier (25 GB / month)
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret

# OR 2. Firebase Storage Free Tier (5 GB free)
FIREBASE_PROJECT_ID=your_firebase_project_id
FIREBASE_STORAGE_BUCKET=your_app.appspot.com

# === Free Persistent Database (MongoDB Atlas M0 Free Tier) ===
MONGODB_URI=mongodb+srv://<username>:<password>@cluster0.mongodb.net/imgvault?retryWrites=true&w=majority
JWT_SECRET=super_secret_jwt_random_key_64_characters`;

  const vercelConfig = `{
  "rewrites": [
    { "source": "/api/(.*)", "destination": "/server.ts" },
    { "source": "/i/(.*)", "destination": "/server.ts" },
    { "source": "/(.*)", "destination": "/index.html" }
  ]
}`;

  return (
    <div className="w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12 space-y-8">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold mb-3">
          <Server className="w-3.5 h-3.5" />
          <span>Production Ready • 100% Free Tier Compatible</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight mb-3">
          Free Hosting &amp; Deployment Guide
        </h1>
        <p className="text-zinc-400 text-sm sm:text-base">
          Step-by-step blueprints to host ImgVault on free cloud platforms (Render, Vercel, Netlify) with Cloudinary/Firebase storage and MongoDB Atlas.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex items-center justify-center gap-2 border-b border-zinc-800 pb-4">
        {[
          { id: 'deploy', label: '1. Hosting Platforms', icon: Server },
          { id: 'storage', label: '2. Free Cloud Storage', icon: Cloud },
          { id: 'database', label: '3. Free Database', icon: Database },
          { id: 'auth_roadmap', label: '4. Auth & Validation Roadmap', icon: ShieldCheck },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeTab === tab.id
                  ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 shadow-sm'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: HOSTING PLATFORMS */}
      {activeTab === 'deploy' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Render.com Card */}
            <div className="p-6 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-4 hover:border-zinc-700 transition-colors">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-1 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-xs font-bold">
                  Recommended
                </span>
                <span className="text-xs font-semibold text-emerald-400">Free Tier</span>
              </div>
              <h3 className="text-lg font-bold text-white">Render.com</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Full Node.js web service support. Handles the Express backend, custom upload endpoints, and Vite frontend together in one free container.
              </p>
              <ul className="text-xs text-zinc-300 space-y-2 list-disc list-inside">
                <li>Build Command: <code className="text-indigo-400">npm run build</code></li>
                <li>Start Command: <code className="text-indigo-400">node server.ts</code> (or <code className="text-indigo-400">tsx server.ts</code>)</li>
                <li>Zero egress limits for free tier API traffic</li>
              </ul>
            </div>

            {/* Vercel Card */}
            <div className="p-6 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-4 hover:border-zinc-700 transition-colors">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-1 rounded bg-zinc-800 text-zinc-300 text-xs font-bold">
                  Serverless
                </span>
                <span className="text-xs font-semibold text-emerald-400">Free Tier</span>
              </div>
              <h3 className="text-lg font-bold text-white">Vercel</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Blazing fast global edge network. Run the Vite frontend as a static SPA and route `/api/1/upload` via Vercel Serverless Functions.
              </p>
              <ul className="text-xs text-zinc-300 space-y-2 list-disc list-inside">
                <li>Automatic Git deployments on every push</li>
                <li>Free HTTPS custom domains</li>
                <li>Requires Cloudinary or S3 for uploads (ephemeral disk)</li>
              </ul>
            </div>

            {/* Netlify Card */}
            <div className="p-6 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-4 hover:border-zinc-700 transition-colors">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-1 rounded bg-zinc-800 text-zinc-300 text-xs font-bold">
                  Static + Edge
                </span>
                <span className="text-xs font-semibold text-emerald-400">Free Tier</span>
              </div>
              <h3 className="text-lg font-bold text-white">Netlify</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Generous free tier with 100GB/month bandwidth. Functions proxy upload requests directly to Cloudinary or Firebase.
              </p>
              <ul className="text-xs text-zinc-300 space-y-2 list-disc list-inside">
                <li>Deploy command: <code className="text-indigo-400">npm run build</code></li>
                <li>Publish directory: <code className="text-indigo-400">dist</code></li>
                <li>Free SSL and branch previews</li>
              </ul>
            </div>
          </div>

          {/* Environment Variables Blueprint */}
          <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 p-6 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                <span>Production Environment Variables (.env)</span>
              </h4>
              <button
                onClick={() => handleCopy(envTemplate, 'env_copy')}
                className="px-3 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs text-zinc-200 flex items-center gap-1.5 transition-colors"
              >
                {copiedKey === 'env_copy' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>Copy .env</span>
              </button>
            </div>
            <pre className="p-4 rounded-xl bg-zinc-950 font-mono text-xs text-zinc-300 overflow-x-auto">
              <code>{envTemplate}</code>
            </pre>
          </div>
        </div>
      )}

      {/* TAB 2: FREE STORAGE */}
      {activeTab === 'storage' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
                <Cloud className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Why External Cloud Storage on Free Tiers?</h3>
                <p className="text-xs text-zinc-400">
                  Platforms like Vercel, Netlify, and Render Free have <strong>ephemeral filesystems</strong> (any uploaded file saved locally is deleted on server restart or redeploy). Storing images on Cloudinary or Firebase ensures your files remain hosted forever for free!
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white text-sm">Option A: Cloudinary (Best Choice)</h4>
                  <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400">25 GB Free</span>
                </div>
                <p className="text-xs text-zinc-400">
                  Provides 25 Credits per month (~25,000 images or 25GB storage), high-speed multi-CDN caching, auto-WebP conversion, and direct upload URLs.
                </p>
                <div className="text-[11px] font-mono text-zinc-300 pt-2 bg-zinc-900 p-2 rounded">
                  <code>npm install cloudinary</code>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white text-sm">Option B: Firebase Storage</h4>
                  <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400">5 GB Free</span>
                </div>
                <p className="text-xs text-zinc-400">
                  Google Cloud Storage backed. 5 GB free storage with 1 GB/day download bandwidth. Excellent for security rules and access control.
                </p>
                <div className="text-[11px] font-mono text-zinc-300 pt-2 bg-zinc-900 p-2 rounded">
                  <code>npm install firebase firebase-admin</code>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: FREE DATABASE */}
      {activeTab === 'database' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center text-violet-400">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">MongoDB Atlas (M0 Forever-Free Cluster)</h3>
                <p className="text-xs text-zinc-400">
                  512 MB forever-free MongoDB database. Ideal for storing millions of image metadata records, user accounts, and API keys.
                </p>
              </div>
            </div>

            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">
                Mongoose User &amp; Image Schema Blueprint
              </h4>
              <pre className="p-4 rounded-xl bg-zinc-950 font-mono text-xs text-zinc-300 overflow-x-auto">
                <code>{`import mongoose from 'mongoose';

const UserSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true, lowercase: true },
  passwordHash: { type: String, required: true },
  name: { type: String, required: true },
  apiKey: { type: String, required: true, unique: true, index: true },
  storageUsedBytes: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
});

const ImageSchema = new mongoose.Schema({
  imageId: { type: String, required: true, unique: true, index: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  title: String,
  storageUrl: { type: String, required: true },
  sizeBytes: Number,
  mimeType: String,
  views: { type: Number, default: 0 },
  deleteToken: { type: String, required: true },
  expiresAt: { type: Date, default: null, index: { expires: 0 } }, // Auto-expiring TTL index!
  createdAt: { type: Date, default: Date.now },
});`}</code>
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: AUTH & VALIDATION ROADMAP */}
      {activeTab === 'auth_roadmap' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Production Authentication &amp; Validation Roadmap</h3>
                <p className="text-xs text-zinc-400">
                  Best practices to harden user authentication and prevent malicious file upload vulnerabilities.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-2">
                <div className="flex items-center gap-2 text-indigo-400 font-semibold text-xs">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>1. Secure User Authentication</span>
                </div>
                <ul className="text-xs text-zinc-400 space-y-1.5 list-disc list-inside">
                  <li>Use <strong>Argon2id</strong> or <strong>bcrypt</strong> with salt rounds &gt;= 12.</li>
                  <li>Issue stateless JWTs signed with 256-bit secret or HTTP-Only secure cookies.</li>
                  <li>API keys hashed in DB with SHA-256 (only display full key once upon creation/reveal).</li>
                  <li>Rate limit `/api/auth/*` to 5 attempts per 15 minutes per IP.</li>
                </ul>
              </div>

              <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-2">
                <div className="flex items-center gap-2 text-indigo-400 font-semibold text-xs">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>2. Image Upload Security &amp; Validation</span>
                </div>
                <ul className="text-xs text-zinc-400 space-y-1.5 list-disc list-inside">
                  <li><strong>Magic Bytes Check:</strong> Never trust client MIME header alone; verify file signature (`FF D8 FF` for JPEG, `89 50 4E 47` for PNG).</li>
                  <li><strong>Sanitize SVG:</strong> Strip embedded <code>&lt;script&gt;</code> and <code>onload</code> attributes using DOMPurify to prevent stored XSS.</li>
                  <li><strong>File Size &amp; Rate Limits:</strong> Enforce 32MB max file size and 100 uploads/hour per API key.</li>
                  <li><strong>Randomized IDs:</strong> Generate non-sequential alphanumeric IDs (`crypto.randomBytes(5)`).</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
