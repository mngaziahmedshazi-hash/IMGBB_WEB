import React, { useState, useRef, useEffect, useCallback } from 'react';
import { User, ImgBBApiResponse } from '../types/index.ts';
import { api } from '../services/api.ts';
import { formatBytes, validateImageFile } from '../utils/formatters.ts';
import { 
  Upload, 
  Image as ImageIcon, 
  Clock, 
  Trash2, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles, 
  Link, 
  ShieldCheck, 
  Zap, 
  Globe, 
  FileCode, 
  ArrowRight,
  Maximize2,
  X,
  Plus,
  Check,
  Layers,
  FileCheck2
} from 'lucide-react';

interface UploadZoneProps {
  user: User | null;
  onUploadSuccess: (uploadResult: ImgBBApiResponse['data']) => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
  onSelectTab: (tab: 'upload' | 'dashboard' | 'api' | 'guide') => void;
}

export interface StagedFile {
  id: string;
  file: File;
  previewUrl: string;
  dataUrl: string;
  title: string;
  sizeFormatted: string;
  sizeBytes: number;
  width?: number;
  height?: number;
  format: string;
}

export const UploadZone: React.FC<UploadZoneProps> = ({
  user,
  onUploadSuccess,
  onOpenAuth,
  onSelectTab,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [stagedFiles, setStagedFiles] = useState<StagedFile[]>([]);
  const [previewingFile, setPreviewingFile] = useState<StagedFile | null>(null);
  const [expiration, setExpiration] = useState<number>(0); // 0 = keep forever
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // File processing helper supporting multiple files
  const processFiles = useCallback((files: FileList | File[]) => {
    setErrorMessage(null);
    const newStagedList: StagedFile[] = [];

    Array.from(files).forEach((file) => {
      const validation = validateImageFile(file, 32);
      if (!validation.valid) {
        setErrorMessage(validation.error || 'Invalid file format.');
        return;
      }

      const reader = new FileReader();
      const objectUrl = URL.createObjectURL(file);
      const rawTitle = file.name.replace(/\.[^/.]+$/, '');
      const ext = file.name.split('.').pop()?.toUpperCase() || 'IMAGE';
      const tempId = `staged_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

      reader.onload = (e) => {
        const dataUrl = e.target?.result as string;

        // Extract native dimensions using temporary Image object
        const tempImg = new Image();
        tempImg.onload = () => {
          const stagedItem: StagedFile = {
            id: tempId,
            file,
            previewUrl: objectUrl,
            dataUrl,
            title: rawTitle,
            sizeFormatted: formatBytes(file.size),
            sizeBytes: file.size,
            width: tempImg.naturalWidth,
            height: tempImg.naturalHeight,
            format: ext,
          };

          setStagedFiles((prev) => {
            // Avoid duplicate by name & size
            if (prev.some((p) => p.file.name === file.name && p.file.size === file.size)) {
              return prev;
            }
            return [...prev, stagedItem];
          });
        };
        tempImg.onerror = () => {
          const stagedItem: StagedFile = {
            id: tempId,
            file,
            previewUrl: objectUrl,
            dataUrl,
            title: rawTitle,
            sizeFormatted: formatBytes(file.size),
            sizeBytes: file.size,
            format: ext,
          };
          setStagedFiles((prev) => [...prev, stagedItem]);
        };
        tempImg.src = objectUrl;
      };
      reader.readAsDataURL(file);
    });
  }, []);

  // Drag and drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFiles(e.target.files);
    }
  };

  // Clipboard paste listener (Ctrl+V anywhere on window)
  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      if (isUploading) return;
      if (e.clipboardData && e.clipboardData.items) {
        const pastedFiles: File[] = [];
        for (let i = 0; i < e.clipboardData.items.length; i++) {
          const item = e.clipboardData.items[i];
          if (item.type.indexOf('image') !== -1) {
            const file = item.getAsFile();
            if (file) pastedFiles.push(file);
          }
        }
        if (pastedFiles.length > 0) {
          processFiles(pastedFiles);
        }
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [processFiles, isUploading]);

  // Remove single staged file
  const handleRemoveStaged = (id: string) => {
    setStagedFiles((prev) => {
      const target = prev.find((item) => item.id === id);
      if (target?.previewUrl) {
        URL.revokeObjectURL(target.previewUrl);
      }
      return prev.filter((item) => item.id !== id);
    });
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Clear all staged files
  const handleClearAll = () => {
    stagedFiles.forEach((item) => {
      if (item.previewUrl) URL.revokeObjectURL(item.previewUrl);
    });
    setStagedFiles([]);
    setErrorMessage(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Update title of an individual staged file
  const handleUpdateTitle = (id: string, newTitle: string) => {
    setStagedFiles((prev) =>
      prev.map((item) => (item.id === id ? { ...item, title: newTitle } : item))
    );
  };

  // Upload submission (handles single and multi-batch)
  const handleStartUpload = async () => {
    if (stagedFiles.length === 0 || isUploading) return;

    setIsUploading(true);
    setUploadProgress(15);
    setErrorMessage(null);

    const progressInterval = setInterval(() => {
      setUploadProgress((prev) => (prev < 90 ? prev + 12 : prev));
    }, 120);

    try {
      let lastUploadedResult: ImgBBApiResponse['data'] | null = null;

      // Upload each staged file sequentially
      for (let i = 0; i < stagedFiles.length; i++) {
        const item = stagedFiles[i];
        const result = await api.uploadImage(item.dataUrl, {
          name: item.title.trim() || item.file.name,
          expiration,
          apiKey: user?.apiKey,
        });
        lastUploadedResult = result;
      }

      clearInterval(progressInterval);
      setUploadProgress(100);

      setTimeout(() => {
        setIsUploading(false);
        handleClearAll();
        setUploadProgress(0);
        if (lastUploadedResult) {
          onUploadSuccess(lastUploadedResult);
        }
      }, 300);
    } catch (err: any) {
      clearInterval(progressInterval);
      setIsUploading(false);
      setUploadProgress(0);
      setErrorMessage(err.message || 'Upload failed. Please check file format and try again.');
    }
  };

  const totalBytes = stagedFiles.reduce((acc, curr) => acc + curr.sizeBytes, 0);

  return (
    <div className="w-full max-w-5xl mx-auto px-3 sm:px-6 py-6 md:py-12 overflow-x-hidden">
      {/* Hero Header */}
      <div className="text-center mb-6 sm:mb-10 px-1">
        <div className="inline-flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-[11px] sm:text-xs font-semibold mb-3 sm:mb-4">
          <Sparkles className="w-3.5 h-3.5 flex-shrink-0" />
          <span>Instant Image-to-URL Conversion &amp; Embed Codes</span>
        </div>
        <h1 className="text-2xl sm:text-4xl md:text-5xl font-black text-white tracking-tight mb-3 sm:mb-4 leading-tight">
          Upload and Share Your Images{' '}
          <span className="bg-gradient-to-r from-indigo-400 via-violet-400 to-cyan-400 bg-clip-text text-transparent">
            Instantly
          </span>
        </h1>
        <p className="text-zinc-400 text-xs sm:text-sm md:text-base max-w-2xl mx-auto leading-relaxed">
          Drag and drop images here, paste from clipboard (Ctrl+V), or upload via API.
          Generates direct links, viewer pages, and HTML/BBCode embeds with zero friction.
        </p>
      </div>

      {/* Upload Box */}
      <div className="relative rounded-2xl bg-zinc-900/70 border border-zinc-800 shadow-2xl backdrop-blur-xl p-3 sm:p-8 transition-all overflow-hidden w-full">
        {/* Glow backdrop decoration */}
        <div className="absolute -top-24 -left-24 w-72 h-72 bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-72 h-72 bg-violet-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Hidden File Input */}
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/jpeg,image/png,image/webp,image/gif,image/svg+xml"
          className="hidden"
          onChange={handleFileChange}
        />

        {stagedFiles.length === 0 ? (
          /* Empty / Drop Target State */
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`cursor-pointer rounded-xl border-2 border-dashed p-6 sm:p-14 text-center transition-all ${
              isDragging
                ? 'border-indigo-400 bg-indigo-500/10 scale-[1.01]'
                : 'border-zinc-700/80 hover:border-indigo-500/50 hover:bg-zinc-800/40'
            }`}
          >
            <div className="mx-auto w-12 h-12 sm:w-20 sm:h-20 rounded-2xl bg-zinc-800/80 border border-zinc-700/80 flex items-center justify-center mb-4 sm:mb-5 text-indigo-400 group-hover:scale-105 transition-transform shadow-inner">
              <Upload className="w-6 h-6 sm:w-10 sm:h-10 text-indigo-400 animate-pulse" />
            </div>

            <h3 className="text-base sm:text-xl font-bold text-white mb-2">
              Drag and drop your images here
            </h3>
            <p className="text-zinc-400 text-xs sm:text-sm mb-5 sm:mb-6 max-w-md mx-auto">
              or <span className="text-indigo-400 font-semibold underline underline-offset-2">browse from your computer</span>. You can also paste directly from your clipboard (<kbd className="px-1.5 py-0.5 rounded bg-zinc-800 text-[10px] sm:text-xs font-mono text-zinc-300 border border-zinc-700">Ctrl+V</kbd>).
            </p>

            <div className="flex flex-wrap items-center justify-center gap-1.5 sm:gap-2 text-[11px] sm:text-xs text-zinc-400">
              <span className="px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md bg-zinc-800/60 border border-zinc-700/50">JPG</span>
              <span className="px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md bg-zinc-800/60 border border-zinc-700/50">PNG</span>
              <span className="px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md bg-zinc-800/60 border border-zinc-700/50">WEBP</span>
              <span className="px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md bg-zinc-800/60 border border-zinc-700/50">GIF</span>
              <span className="px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md bg-zinc-800/60 border border-zinc-700/50">SVG</span>
              <span className="text-zinc-400 text-[11px] sm:text-xs block sm:inline mt-1 sm:mt-0">• Max 32 MB per file</span>
            </div>
          </div>
        ) : (
          /* Staged Files Confirmation & Thumbnail Preview Grid */
          <div className="space-y-6">
            {/* Header with summary count & actions */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-zinc-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 flex-shrink-0">
                  <FileCheck2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm sm:text-base flex items-center gap-2">
                    <span>{stagedFiles.length} {stagedFiles.length === 1 ? 'Image' : 'Images'} Selected</span>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-300 font-mono">
                      {formatBytes(totalBytes)}
                    </span>
                  </h3>
                  <p className="text-xs text-zinc-400">
                    Confirm thumbnails and titles below before generating direct URLs.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading}
                  className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold transition-colors flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Add More</span>
                </button>

                <button
                  type="button"
                  onClick={handleClearAll}
                  disabled={isUploading}
                  className="px-3 py-1.5 rounded-lg border border-zinc-700 hover:bg-rose-500/10 hover:border-rose-500/30 text-zinc-400 hover:text-rose-400 text-xs font-medium transition-colors flex items-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear All</span>
                </button>
              </div>
            </div>

            {/* Thumbnail Preview Grid */}
            <div className={`grid gap-4 ${
              stagedFiles.length === 1 
                ? 'grid-cols-1' 
                : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
            }`}>
              {stagedFiles.map((item, idx) => (
                <div
                  key={item.id}
                  className="relative group rounded-xl bg-zinc-950/80 border border-zinc-800 hover:border-zinc-700 p-3 flex flex-col justify-between transition-all"
                >
                  {/* Thumbnail Image Stage with Hover Zoom */}
                  <div className="relative aspect-video w-full rounded-lg bg-zinc-900 border border-zinc-800/80 overflow-hidden flex items-center justify-center mb-3 group/thumb">
                    <img
                      src={item.previewUrl}
                      alt={item.title}
                      className="w-full h-full object-contain"
                    />

                    {/* Format and Size Overlay Pill */}
                    <div className="absolute top-2 left-2 flex items-center gap-1">
                      <span className="px-1.5 py-0.5 rounded bg-black/80 text-[10px] font-mono font-bold text-indigo-300 border border-indigo-500/30 backdrop-blur-sm">
                        {item.format}
                      </span>
                      {item.width && item.height && (
                        <span className="px-1.5 py-0.5 rounded bg-black/80 text-[10px] font-mono text-zinc-300 border border-zinc-700/50 backdrop-blur-sm hidden sm:inline">
                          {item.width}×{item.height}
                        </span>
                      )}
                    </div>

                    {/* Remove button */}
                    <button
                      type="button"
                      onClick={() => handleRemoveStaged(item.id)}
                      disabled={isUploading}
                      className="absolute top-2 right-2 p-1 rounded-md bg-black/80 hover:bg-rose-600 text-zinc-400 hover:text-white border border-zinc-700/50 transition-colors"
                      title="Remove from upload queue"
                      aria-label="Remove image"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>

                    {/* Zoom / Full Preview Trigger */}
                    <button
                      type="button"
                      onClick={() => setPreviewingFile(item)}
                      className="absolute inset-0 bg-black/50 opacity-0 group-hover/thumb:opacity-100 transition-opacity flex items-center justify-center gap-1.5 text-white text-xs font-semibold backdrop-blur-[2px]"
                    >
                      <Maximize2 className="w-4 h-4 text-indigo-400" />
                      <span>Click to preview full size</span>
                    </button>
                  </div>

                  {/* Title & Metadata Inputs */}
                  <div className="space-y-2">
                    <div>
                      <label className="block text-[11px] font-medium text-zinc-400 mb-1">
                        Title / File Name
                      </label>
                      <input
                        type="text"
                        value={item.title}
                        onChange={(e) => handleUpdateTitle(item.id, e.target.value)}
                        disabled={isUploading}
                        className="w-full px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500 transition-colors"
                        placeholder="Image title"
                      />
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-zinc-400 pt-1">
                      <span>Size: <strong className="text-zinc-200">{item.sizeFormatted}</strong></span>
                      {item.width && item.height && (
                        <span>Dimensions: <strong className="text-zinc-200">{item.width}×{item.height}</strong></span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Global Expiration Selector */}
            <div className="p-4 rounded-xl bg-zinc-950/60 border border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-zinc-400 flex-shrink-0" />
                <div>
                  <span className="text-xs font-semibold text-zinc-200 block">
                    Auto-Delete / Expiration Schedule
                  </span>
                  <span className="text-[11px] text-zinc-400">
                    Direct links remain active until the selected duration elapses.
                  </span>
                </div>
              </div>

              <select
                value={expiration}
                onChange={(e) => setExpiration(parseInt(e.target.value, 10))}
                disabled={isUploading}
                className="px-3.5 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-zinc-200 focus:outline-none focus:border-indigo-500"
              >
                <option value={0}>Don't autodelete (Keep forever)</option>
                <option value={300}>After 5 minutes</option>
                <option value={900}>After 15 minutes</option>
                <option value={3600}>After 1 hour</option>
                <option value={86400}>After 1 day</option>
                <option value={604800}>After 1 week</option>
                <option value={2592000}>After 1 month</option>
              </select>
            </div>

            {/* Progress Bar */}
            {isUploading && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-medium text-zinc-300">
                  <span className="flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-indigo-400 animate-spin" />
                    Uploading and generating direct CDN links...
                  </span>
                  <span>{uploadProgress}%</span>
                </div>
                <div className="w-full h-2 rounded-full bg-zinc-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-indigo-500 via-violet-500 to-cyan-400 rounded-full transition-all duration-200"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
              </div>
            )}

            {/* Confirmation & Upload Button Bar */}
            <div className="flex flex-col-reverse sm:flex-row items-center justify-between gap-3 pt-2">
              <button
                type="button"
                onClick={handleClearAll}
                disabled={isUploading}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-zinc-700 text-zinc-400 hover:text-rose-400 hover:border-rose-500/30 hover:bg-rose-500/10 text-xs sm:text-sm font-medium transition-colors flex items-center justify-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                <span>Cancel Selection</span>
              </button>

              <button
                type="button"
                onClick={handleStartUpload}
                disabled={isUploading}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 via-violet-600 to-indigo-600 text-white font-semibold text-xs sm:text-sm shadow-lg shadow-indigo-600/30 hover:shadow-indigo-600/50 hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                <Check className="w-4 h-4" />
                <span>
                  {isUploading
                    ? `Uploading (${uploadProgress}%)...`
                    : `Confirm & Upload ${stagedFiles.length === 1 ? 'Image' : `(${stagedFiles.length} Images)`}`}
                </span>
              </button>
            </div>
          </div>
        )}

        {/* Error notification */}
        {errorMessage && (
          <div className="mt-4 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center gap-3 text-rose-300 text-xs sm:text-sm">
            <AlertCircle className="w-5 h-5 flex-shrink-0 text-rose-400" />
            <p>{errorMessage}</p>
          </div>
        )}
      </div>

      {/* Full Size Preview Lightbox Modal */}
      {previewingFile && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-150"
          role="dialog"
          aria-modal="true"
        >
          <div className="relative max-w-4xl w-full rounded-2xl bg-zinc-900 border border-zinc-800 p-4 sm:p-6 flex flex-col max-h-[90vh] overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div className="truncate mr-4">
                <h4 className="font-bold text-white text-sm truncate">{previewingFile.title}</h4>
                <p className="text-xs text-zinc-400">
                  {previewingFile.format} • {previewingFile.sizeFormatted} {previewingFile.width ? `• ${previewingFile.width}×${previewingFile.height}px` : ''}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPreviewingFile(null)}
                className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
                aria-label="Close preview"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="my-4 flex-1 overflow-auto flex items-center justify-center bg-zinc-950/80 rounded-xl p-2 min-h-[300px]">
              <img
                src={previewingFile.previewUrl}
                alt={previewingFile.title}
                className="max-h-[65vh] w-auto max-w-full object-contain rounded-lg"
              />
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-xs text-zinc-400">Pre-upload confirmation</span>
              <button
                type="button"
                onClick={() => setPreviewingFile(null)}
                className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Guest / Account Info Banner */}
      {!user && (
        <div className="mt-6 p-4 rounded-xl bg-zinc-900/40 border border-zinc-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs sm:text-sm text-zinc-400">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400 flex-shrink-0">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <span>
              Uploading as <strong className="text-zinc-200">Guest</strong>. Create an account to organize your images, manage direct links, and get a personal API key!
            </span>
          </div>
          <button
            onClick={() => onOpenAuth('register')}
            className="flex-shrink-0 px-3.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-semibold transition-colors flex items-center gap-1.5"
          >
            <span>Register Free</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Feature Highlights Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-12">
        <div className="p-5 rounded-xl bg-zinc-900/40 border border-zinc-800/80 hover:border-zinc-700/80 transition-colors">
          <div className="w-10 h-10 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 mb-3">
            <Link className="w-5 h-5" />
          </div>
          <h4 className="font-semibold text-white text-sm mb-1">Instant Direct Links</h4>
          <p className="text-zinc-400 text-xs leading-relaxed">
            Direct image CDN URLs (`/i/:id`), viewer pages, and automated markdown embeds.
          </p>
        </div>

        <div className="p-5 rounded-xl bg-zinc-900/40 border border-zinc-800/80 hover:border-zinc-700/80 transition-colors">
          <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 mb-3">
            <FileCode className="w-5 h-5" />
          </div>
          <h4 className="font-semibold text-white text-sm mb-1">ImgBB API v1 Compatible</h4>
          <p className="text-zinc-400 text-xs leading-relaxed">
            Upload from cURL, Python, Node.js, or ShareX using your private API key token.
          </p>
        </div>

        <div className="p-5 rounded-xl bg-zinc-900/40 border border-zinc-800/80 hover:border-zinc-700/80 transition-colors">
          <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 mb-3">
            <Globe className="w-5 h-5" />
          </div>
          <h4 className="font-semibold text-white text-sm mb-1">100% Free Hosting Ready</h4>
          <p className="text-zinc-400 text-xs leading-relaxed">
            Pluggable Cloudinary/Firebase storage engine ready for free Vercel, Render, or Netlify hosting.
          </p>
        </div>
      </div>
    </div>
  );
};
