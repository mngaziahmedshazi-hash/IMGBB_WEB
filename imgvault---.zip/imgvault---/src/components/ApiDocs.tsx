import React, { useState } from 'react';
import { User, ImgBBApiResponse } from '../types/index.ts';
import { 
  Code2, 
  Terminal, 
  Copy, 
  Check, 
  Send, 
  Sparkles, 
  Download, 
  Key, 
  Layers, 
  CheckCircle2, 
  AlertCircle 
} from 'lucide-react';

import { copyToClipboard } from '../utils/clipboard.ts';

interface ApiDocsProps {
  user: User | null;
  onOpenAuth: (mode: 'login' | 'register') => void;
}

export const ApiDocs: React.FC<ApiDocsProps> = ({ user, onOpenAuth }) => {
  const [activeLang, setActiveLang] = useState<'curl' | 'javascript' | 'python' | 'php' | 'sharex'>('curl');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Live tester states
  const [testApiKey, setTestApiKey] = useState(user?.apiKey || 'iv_live_demo887766554433221100aabbccddee');
  const [testImageBase64, setTestImageBase64] = useState<string>(
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=='
  );
  const [testName, setTestName] = useState('test-upload');
  const [testExpiration, setTestExpiration] = useState(0);
  const [isTesting, setIsTesting] = useState(false);
  const [testResponse, setTestResponse] = useState<any | null>(null);

  const origin = typeof window !== 'undefined' ? window.location.origin : 'https://imgvault.dev';
  const effectiveKey = user?.apiKey || testApiKey;

  const handleCopy = async (text: string, id: string) => {
    await copyToClipboard(text);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  // Run live API test
  const handleExecuteTest = async () => {
    setIsTesting(true);
    setTestResponse(null);
    try {
      const res = await fetch('/api/1/upload', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-API-Key': testApiKey,
        },
        body: JSON.stringify({
          key: testApiKey,
          image: testImageBase64,
          name: testName,
          expiration: testExpiration,
        }),
      });
      const data = await res.json();
      setTestResponse({ status: res.status, ok: res.ok, body: data });
    } catch (err: any) {
      setTestResponse({ status: 500, ok: false, body: { error: err.message } });
    } finally {
      setIsTesting(false);
    }
  };

  // Code snippets
  const snippets = {
    curl: `curl --location --request POST '${origin}/api/1/upload' \\
  --header 'X-API-Key: ${effectiveKey}' \\
  --form 'key="${effectiveKey}"' \\
  --form 'image="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAE..."' \\
  --form 'name="my-avatar"' \\
  --form 'expiration="3600"'`,

    javascript: `// Modern Fetch / Node.js
const uploadImage = async (base64Image) => {
  const response = await fetch('${origin}/api/1/upload', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': '${effectiveKey}',
    },
    body: JSON.stringify({
      key: '${effectiveKey}',
      image: base64Image,
      name: 'screenshot-01',
      expiration: 0, // 0 = keep forever
    }),
  });

  const data = await response.json();
  console.log('Direct CDN URL:', data.data.url);
  console.log('Viewer Page:', data.data.url_viewer);
  return data;
};`,

    python: `import requests
import base64

url = "${origin}/api/1/upload"

payload = {
    "key": "${effectiveKey}",
    "image": "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==",
    "name": "python_upload",
    "expiration": 0
}
headers = {
    "Content-Type": "application/json",
    "X-API-Key": "${effectiveKey}"
}

response = requests.post(url, json=payload, headers=headers)
print(response.json())
`,

    php: `<?php
$curl = curl_init();

$payload = json_encode([
    'key' => '${effectiveKey}',
    'image' => 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
    'name' => 'php_image_upload',
    'expiration' => 0
]);

curl_setopt_array($curl, [
    CURLOPT_URL => '${origin}/api/1/upload',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => $payload,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'X-API-Key: ${effectiveKey}'
    ],
]);

$response = curl_exec($curl);
curl_close($curl);
echo $response;
?>`,

    sharex: `{
  "Version": "15.0.0",
  "Name": "ImgVault (${user?.name || 'Custom'})",
  "DestinationType": "ImageUploader",
  "RequestMethod": "POST",
  "RequestURL": "${origin}/api/1/upload",
  "Headers": {
    "X-API-Key": "${effectiveKey}"
  },
  "Body": "MultipartFormData",
  "FileFormName": "image",
  "URL": "$json:data.url$",
  "ThumbnailURL": "$json:data.thumb.url$",
  "DeletionURL": "$json:data.delete_url$"
}`,
  };

  return (
    <div className="w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12 space-y-10">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-semibold mb-3">
          <Terminal className="w-3.5 h-3.5" />
          <span>ImgBB v1 Compatible REST API</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight mb-3">
          Developer API Documentation
        </h1>
        <p className="text-zinc-400 text-sm sm:text-base">
          Integrate programmatic image uploads directly into your applications, command line tools, bots, or ShareX using standard ImgBB v1 format.
        </p>
      </div>

      {/* User API Key status banner */}
      <div className="p-5 rounded-2xl bg-zinc-900/80 border border-zinc-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 flex-shrink-0">
            <Key className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-white text-sm">
              {user ? 'Authenticated with your personal API Key' : 'Using Demo API Key'}
            </h3>
            <p className="text-xs font-mono text-zinc-400 truncate max-w-md">
              {effectiveKey}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => handleCopy(effectiveKey, 'api_banner')}
            className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium transition-colors flex items-center gap-1.5"
          >
            {copiedKey === 'api_banner' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>Copy Key</span>
          </button>
          {!user && (
            <button
              onClick={() => onOpenAuth('register')}
              className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition-all"
            >
              Get Your Own Key
            </button>
          )}
        </div>
      </div>

      {/* Endpoint Specification Table */}
      <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 overflow-hidden">
        <div className="px-6 py-4 bg-zinc-950/70 border-b border-zinc-800 flex items-center gap-3">
          <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-mono font-bold">
            POST
          </span>
          <span className="font-mono text-sm text-zinc-200 font-semibold">
            {origin}/api/1/upload
          </span>
          <span className="text-zinc-500 text-xs hidden sm:inline">(also /1/upload)</span>
        </div>

        <div className="p-6 space-y-6">
          <div>
            <h4 className="text-xs font-bold text-zinc-400 uppercase tracking-wider mb-3">
              Request Parameters
            </h4>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-zinc-300">
                <thead>
                  <tr className="border-b border-zinc-800 text-zinc-500 uppercase font-semibold">
                    <th className="py-2 pr-4">Parameter</th>
                    <th className="py-2 pr-4">Type</th>
                    <th className="py-2 pr-4">Required</th>
                    <th className="py-2">Description</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/60 font-mono">
                  <tr>
                    <td className="py-3 pr-4 text-indigo-400 font-bold">key</td>
                    <td className="py-3 pr-4 text-zinc-400">string</td>
                    <td className="py-3 pr-4 text-amber-400">Required</td>
                    <td className="py-3 text-zinc-300 font-sans">
                      Your unique user API key token. Can be passed via body, query param, or <code className="text-zinc-200 font-mono">X-API-Key</code> header.
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3 pr-4 text-indigo-400 font-bold">image</td>
                    <td className="py-3 pr-4 text-zinc-400">string / binary</td>
                    <td className="py-3 pr-4 text-amber-400">Required</td>
                    <td className="py-3 text-zinc-300 font-sans">
                      A binary file, base64 encoded string, or a direct public image URL to import.
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3 pr-4 text-indigo-400 font-bold">name</td>
                    <td className="py-3 pr-4 text-zinc-400">string</td>
                    <td className="py-3 pr-4 text-zinc-500">Optional</td>
                    <td className="py-3 text-zinc-300 font-sans">
                      Custom title or file name for the hosted asset.
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3 pr-4 text-indigo-400 font-bold">expiration</td>
                    <td className="py-3 pr-4 text-zinc-400">integer</td>
                    <td className="py-3 pr-4 text-zinc-500">Optional</td>
                    <td className="py-3 text-zinc-300 font-sans">
                      Auto-delete duration in seconds (e.g. 300 for 5m, 86400 for 1 day). 0 means permanent.
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Code Snippets Section */}
      <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800 overflow-hidden">
        {/* Language Tabs */}
        <div className="flex items-center justify-between px-6 py-3 bg-zinc-950 border-b border-zinc-800">
          <div className="flex items-center gap-1 overflow-x-auto">
            {(['curl', 'javascript', 'python', 'php', 'sharex'] as const).map((lang) => (
              <button
                key={lang}
                onClick={() => setActiveLang(lang)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all ${
                  activeLang === lang
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
                }`}
              >
                {lang === 'sharex' ? 'ShareX (.sxcu)' : lang}
              </button>
            ))}
          </div>

          <button
            onClick={() => handleCopy(snippets[activeLang], activeLang)}
            className="flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium text-zinc-300 hover:text-white bg-zinc-800 hover:bg-zinc-700 transition-colors"
          >
            {copiedKey === activeLang ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>Copy Snippet</span>
          </button>
        </div>

        {/* Code Content */}
        <div className="p-6 bg-zinc-950 font-mono text-xs overflow-x-auto">
          <pre className="text-zinc-200 leading-relaxed">
            <code>{snippets[activeLang]}</code>
          </pre>
        </div>
      </div>

      {/* Interactive Live API Console */}
      <div className="rounded-2xl bg-zinc-900/70 border border-zinc-800 p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Live API Test Console</h3>
              <p className="text-xs text-zinc-400">
                Trigger a real HTTP POST request to the API right now and inspect the JSON payload.
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-zinc-400 mb-1">API Key</label>
            <input
              type="text"
              value={testApiKey}
              onChange={(e) => setTestApiKey(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-800 font-mono text-xs text-zinc-200 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-400 mb-1">Image Name</label>
            <input
              type="text"
              value={testName}
              onChange={(e) => setTestName(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-800 font-mono text-xs text-zinc-200 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        <div className="flex items-center justify-between pt-2">
          <span className="text-xs text-zinc-400">
            Sending sample 1x1 base64 pixel payload
          </span>

          <button
            onClick={handleExecuteTest}
            disabled={isTesting}
            className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-lg shadow-indigo-600/30 flex items-center gap-2 transition-all"
          >
            <Send className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
            <span>{isTesting ? 'Sending Request...' : 'Send Test Request'}</span>
          </button>
        </div>

        {/* Live Response Result */}
        {testResponse && (
          <div className="space-y-2 pt-2 animate-in fade-in">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-zinc-300">Live Response:</span>
              <span className={`px-2 py-0.5 rounded font-mono font-bold ${testResponse.ok ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                HTTP {testResponse.status}
              </span>
            </div>
            <pre className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 text-[11px] font-mono text-emerald-400 overflow-x-auto max-h-72">
              <code>{JSON.stringify(testResponse.body, null, 2)}</code>
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};
