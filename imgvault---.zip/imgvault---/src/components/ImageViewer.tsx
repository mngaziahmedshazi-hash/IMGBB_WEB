import React, { useState, useEffect } from 'react';
import { api } from '../services/api.ts';
import { generateEmbedCodes, formatBytes } from '../utils/formatters.ts';
import { copyToClipboard } from '../utils/clipboard.ts';
import { 
  ArrowLeft, 
  Copy, 
  Check, 
  Download, 
  ExternalLink, 
  Eye, 
  Calendar, 
  HardDrive, 
  FileText, 
  Code2, 
  Sparkles,
  Share2
} from 'lucide-react';

interface ImageViewerProps {
  imageId: string;
  onBack: () => void;
}

export const ImageViewer: React.FC<ImageViewerProps> = ({ imageId, onBack }) => {
  const [image, setImage] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  useEffect(() => {
    async function fetchImage() {
      setIsLoading(true);
      setError(null);
      try {
        const data = await api.getImage(imageId);
        setImage(data);
      } catch (err: any) {
        setError(err.message || 'Image not found.');
      } finally {
        setIsLoading(false);
      }
    }
    fetchImage();
  }, [imageId]);

  const handleCopy = async (text: string, key: string) => {
    await copyToClipboard(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleDownload = () => {
    if (!image) return;
    const a = document.createElement('a');
    a.href = image.directUrl;
    a.download = image.filename || `image-${image.id}.png`;
    a.target = '_blank';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  if (isLoading) {
    return (
      <div className="w-full max-w-5xl mx-auto px-4 py-20 text-center text-zinc-400">
        <Sparkles className="w-8 h-8 text-indigo-400 animate-spin mx-auto mb-3" />
        <p className="text-sm">Loading image details...</p>
      </div>
    );
  }

  if (error || !image) {
    return (
      <div className="w-full max-w-md mx-auto px-4 py-20 text-center">
        <div className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800">
          <h3 className="text-lg font-bold text-white mb-2">Image Not Available</h3>
          <p className="text-xs text-zinc-400 mb-6">{error || 'This image does not exist or has expired.'}</p>
          <button
            onClick={onBack}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold"
          >
            &larr; Go Back
          </button>
        </div>
      </div>
    );
  }

  const embedCodes = generateEmbedCodes(
    {
      id: image.id,
      title: image.title,
      filename: image.filename,
      mimeType: image.mimeType,
      storageUrl: image.directUrl,
    },
    typeof window !== 'undefined' ? window.location.origin : ''
  );

  return (
    <div className="w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Back button */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-zinc-400 hover:text-white text-sm font-medium transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={handleDownload}
            className="px-3.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium transition-colors flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download</span>
          </button>

          <a
            href={image.directUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-md shadow-indigo-600/30"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Open Raw</span>
          </a>
        </div>
      </div>

      {/* Main Image Stage */}
      <div className="rounded-2xl bg-zinc-900/80 border border-zinc-800 p-4 sm:p-8 flex items-center justify-center min-h-[400px] max-h-[700px] overflow-hidden">
        <img
          src={image.directUrl}
          alt={image.title}
          className="max-h-[600px] w-auto max-w-full object-contain rounded-lg shadow-2xl"
        />
      </div>

      {/* Details & Embed Codes Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Metadata Card */}
        <div className="p-6 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-4">
          <h3 className="font-bold text-white text-base">Image Information</h3>

          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between py-2 border-b border-zinc-800">
              <span className="text-zinc-400 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-zinc-500" />
                Title
              </span>
              <span className="text-zinc-200 font-medium truncate max-w-[160px]">{image.title}</span>
            </div>

            <div className="flex items-center justify-between py-2 border-b border-zinc-800">
              <span className="text-zinc-400 flex items-center gap-1.5">
                <HardDrive className="w-3.5 h-3.5 text-zinc-500" />
                File Size
              </span>
              <span className="text-zinc-200 font-mono">{formatBytes(image.sizeBytes)}</span>
            </div>

            <div className="flex items-center justify-between py-2 border-b border-zinc-800">
              <span className="text-zinc-400 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-zinc-500" />
                Uploaded
              </span>
              <span className="text-zinc-200 font-mono">
                {new Date(image.createdAt).toLocaleDateString()}
              </span>
            </div>

            <div className="flex items-center justify-between py-2 border-b border-zinc-800">
              <span className="text-zinc-400 flex items-center gap-1.5">
                <Eye className="w-3.5 h-3.5 text-zinc-500" />
                Views
              </span>
              <span className="text-emerald-400 font-semibold">{image.views}</span>
            </div>

            <div className="flex items-center justify-between py-2">
              <span className="text-zinc-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-zinc-500" />
                Expiration
              </span>
              <span className="text-zinc-200">
                {image.expiresAt ? new Date(image.expiresAt).toLocaleString() : 'Permanent'}
              </span>
            </div>
          </div>
        </div>

        {/* Embed Codes Card */}
        <div className="lg:col-span-2 p-6 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              <Code2 className="w-4 h-4 text-indigo-400" />
              <span>Embed Codes &amp; Share Links</span>
            </h3>
            <span className="text-xs text-zinc-400">One-click copy</span>
          </div>

          <div className="space-y-3">
            {[
              { label: 'Direct Image URL', value: embedCodes.directUrl, id: 'direct' },
              { label: 'Viewer Page Link', value: embedCodes.viewerUrl, id: 'viewer' },
              { label: 'BBCode Full Linked (Forums)', value: embedCodes.bbcodeFull, id: 'bbcode' },
              { label: 'HTML Embed Code', value: embedCodes.htmlFull, id: 'html' },
              { label: 'Markdown (GitHub / Discord / Reddit)', value: embedCodes.markdown, id: 'md' },
            ].map((item) => (
              <div key={item.id} className="space-y-1">
                <div className="flex items-center justify-between text-[11px] font-medium text-zinc-400">
                  <span>{item.label}</span>
                  {copiedKey === item.id && <span className="text-emerald-400">Copied!</span>}
                </div>
                <div className="flex items-center gap-2 p-2 rounded-xl bg-zinc-950 border border-zinc-800">
                  <input
                    type="text"
                    readOnly
                    value={item.value}
                    className="w-full bg-transparent border-none text-zinc-300 font-mono text-xs focus:outline-none"
                    onClick={(e) => (e.target as HTMLInputElement).select()}
                  />
                  <button
                    onClick={() => handleCopy(item.value, item.id)}
                    className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
                  >
                    {copiedKey === item.id ? (
                      <Check className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
