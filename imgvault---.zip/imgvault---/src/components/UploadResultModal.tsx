import React, { useState } from 'react';
import { ImgBBApiResponse, EmbedCodes } from '../types/index.ts';
import { generateEmbedCodes, formatBytes } from '../utils/formatters.ts';
import { 
  Check, 
  Copy, 
  ExternalLink, 
  Download, 
  X, 
  Code, 
  Link2, 
  Sparkles, 
  Eye, 
  Trash2,
  Share2
} from 'lucide-react';

interface UploadResultModalProps {
  uploadData: ImgBBApiResponse['data'];
  onClose: () => void;
  onUploadAnother: () => void;
}

import { copyToClipboard } from '../utils/clipboard.ts';

type CodeType = 'directUrl' | 'viewerUrl' | 'htmlFull' | 'htmlThumb' | 'bbcodeFull' | 'bbcodeThumb' | 'markdown';

export const UploadResultModal: React.FC<UploadResultModalProps> = ({
  uploadData,
  onClose,
  onUploadAnother,
}) => {
  const [selectedFormat, setSelectedFormat] = useState<CodeType>('directUrl');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const embedCodes: EmbedCodes = generateEmbedCodes(
    {
      id: uploadData.id,
      title: uploadData.title,
      filename: uploadData.image?.filename || 'image.png',
      mimeType: uploadData.image?.mime || 'image/png',
      storageUrl: uploadData.url,
    },
    typeof window !== 'undefined' ? window.location.origin : ''
  );

  const formatOptions: { id: CodeType; label: string; description: string }[] = [
    { id: 'directUrl', label: 'Direct Image Link', description: 'Raw direct URL to image file for hotlinking' },
    { id: 'viewerUrl', label: 'Viewer Page Link', description: 'Dedicated ImgVault / ImgBB viewer webpage' },
    { id: 'htmlFull', label: 'HTML Full Linked', description: 'HTML tag embedding full image linked to viewer' },
    { id: 'htmlThumb', label: 'HTML Thumbnail Linked', description: 'HTML thumbnail linked to viewer page' },
    { id: 'bbcodeFull', label: 'BBCode Full Linked', description: 'Forum BBCode for phpBB, vBulletin, XenForo' },
    { id: 'bbcodeThumb', label: 'BBCode Thumbnail', description: 'Forum BBCode with thumbnail' },
    { id: 'markdown', label: 'Markdown Embed', description: 'GitHub, Reddit, Discord, and Notion compatible' },
  ];

  const currentCode = embedCodes[selectedFormat] || '';

  const handleCopy = async (text: string, key: string) => {
    await copyToClipboard(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-3xl rounded-2xl bg-zinc-900 border border-zinc-800 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden"
        role="dialog"
        aria-modal="true"
        aria-labelledby="upload-success-title"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-950/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 id="upload-success-title" className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                Upload Complete!
              </h2>
              <p className="text-xs text-zinc-400">
                Direct CDN URLs and embed codes ready
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6 overflow-y-auto">
          {/* Preview + File Specs */}
          <div className="flex flex-col sm:flex-row gap-5 items-center p-4 rounded-xl bg-zinc-950/60 border border-zinc-800/80">
            <div className="w-40 h-32 rounded-lg bg-zinc-900 border border-zinc-800 overflow-hidden flex items-center justify-center flex-shrink-0">
              <img
                src={uploadData.display_url || uploadData.url}
                alt={uploadData.title}
                className="w-full h-full object-contain"
              />
            </div>

            <div className="flex-1 w-full space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-white text-base truncate max-w-xs">
                  {uploadData.title || uploadData.image.filename}
                </h3>
                <span className="text-xs px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 font-mono">
                  {uploadData.image.extension.toUpperCase()}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs text-zinc-400">
                <div>
                  <span className="text-zinc-400 block text-[11px]">Size</span>
                  <span className="text-zinc-200 font-medium">{formatBytes(uploadData.size)}</span>
                </div>
                <div>
                  <span className="text-zinc-400 block text-[11px]">Expiration</span>
                  <span className="text-zinc-200 font-medium">
                    {uploadData.expiration === '0' ? 'Keep forever' : `${uploadData.expiration}s`}
                  </span>
                </div>
                <div>
                  <span className="text-zinc-400 block text-[11px]">Format</span>
                  <span className="text-zinc-200 font-medium">{uploadData.image.mime}</span>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-2">
                <a
                  href={uploadData.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium transition-colors flex items-center gap-1.5"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Open Direct URL</span>
                </a>
                <a
                  href={uploadData.url_viewer}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium transition-colors flex items-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Viewer Page</span>
                </a>
              </div>
            </div>
          </div>

          {/* Embed Code Format Selector */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-zinc-300 uppercase tracking-wider flex items-center gap-1.5">
                <Code className="w-3.5 h-3.5 text-indigo-400" />
                <span>Embed Code Format</span>
              </label>
              <span className="text-xs text-zinc-400">
                {formatOptions.find((o) => o.id === selectedFormat)?.description}
              </span>
            </div>

            <div className="flex flex-wrap gap-1.5 p-1 rounded-xl bg-zinc-950 border border-zinc-800">
              {formatOptions.map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => setSelectedFormat(opt.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    selectedFormat === opt.id
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>

            {/* Code Output Box */}
            <div className="relative rounded-xl bg-zinc-950 border border-zinc-800 p-3.5 font-mono text-xs text-zinc-200 flex items-center justify-between gap-3 group">
              <input
                type="text"
                readOnly
                value={currentCode}
                className="w-full bg-transparent border-none text-zinc-200 focus:outline-none selection:bg-indigo-500/30 font-mono text-xs"
                onClick={(e) => (e.target as HTMLInputElement).select()}
              />

              <button
                onClick={() => handleCopy(currentCode, selectedFormat)}
                className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  copiedKey === selectedFormat
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/20 active:scale-95'
                }`}
              >
                {copiedKey === selectedFormat ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Quick Links Summary Grid */}
          <div className="space-y-2 pt-2">
            <h4 className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">
              Quick Copy Links
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="flex items-center justify-between p-2.5 rounded-lg bg-zinc-950/60 border border-zinc-800">
                <div className="truncate mr-2">
                  <span className="text-zinc-400 block text-[10px]">Direct Image URL</span>
                  <span className="text-zinc-300 truncate font-mono text-xs">{embedCodes.directUrl}</span>
                </div>
                <button
                  onClick={() => handleCopy(embedCodes.directUrl, 'quick_direct')}
                  className="p-1.5 rounded-md hover:bg-zinc-800 text-zinc-400 hover:text-white"
                  title="Copy Direct URL"
                >
                  {copiedKey === 'quick_direct' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>

              <div className="flex items-center justify-between p-2.5 rounded-lg bg-zinc-950/60 border border-zinc-800">
                <div className="truncate mr-2">
                  <span className="text-zinc-400 block text-[10px]">Viewer Page URL</span>
                  <span className="text-zinc-300 truncate font-mono text-xs">{embedCodes.viewerUrl}</span>
                </div>
                <button
                  onClick={() => handleCopy(embedCodes.viewerUrl, 'quick_viewer')}
                  className="p-1.5 rounded-md hover:bg-zinc-800 text-zinc-400 hover:text-white"
                  title="Copy Viewer URL"
                >
                  {copiedKey === 'quick_viewer' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          </div>

          {/* Deletion Link Alert */}
          {uploadData.delete_url && (
            <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800/80 flex items-center justify-between text-xs text-zinc-400">
              <div className="flex items-center gap-2">
                <Trash2 className="w-3.5 h-3.5 text-zinc-400" />
                <span>Keep your deletion link safe if you uploaded as guest:</span>
              </div>
              <button
                onClick={() => handleCopy(uploadData.delete_url, 'delete_url')}
                className="text-xs text-indigo-400 hover:text-indigo-300 font-medium underline underline-offset-2 flex items-center gap-1"
              >
                {copiedKey === 'delete_url' ? 'Copied Deletion Link!' : 'Copy Delete Link'}
              </button>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-zinc-800 bg-zinc-950/60">
          <button
            onClick={onUploadAnother}
            className="px-4 py-2 rounded-xl border border-zinc-700 hover:bg-zinc-800 text-zinc-300 text-xs sm:text-sm font-medium transition-colors"
          >
            Upload Another Image
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs sm:text-sm font-semibold shadow-lg shadow-indigo-600/30 transition-all active:scale-95"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
