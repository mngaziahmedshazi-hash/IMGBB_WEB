import React, { useState } from 'react';
import { User } from '../types/index.ts';
import { 
  CloudUpload, 
  LayoutDashboard, 
  Code2, 
  Server, 
  Key, 
  LogOut, 
  User as UserIcon,
  Copy,
  Check,
  Sparkles,
  Menu,
  X
} from 'lucide-react';

import { copyToClipboard } from '../utils/clipboard.ts';

interface NavbarProps {
  currentTab: 'upload' | 'dashboard' | 'api' | 'guide';
  onSelectTab: (tab: 'upload' | 'dashboard' | 'api' | 'guide') => void;
  user: User | null;
  onOpenAuth: (mode: 'login' | 'register') => void;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  user,
  onOpenAuth,
  onLogout,
}) => {
  const [copiedKey, setCopiedKey] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleCopyKey = async () => {
    if (user?.apiKey) {
      await copyToClipboard(user.apiKey);
      setCopiedKey(true);
      setTimeout(() => setCopiedKey(false), 2000);
    }
  };

  const handleTabClick = (tab: 'upload' | 'dashboard' | 'api' | 'guide') => {
    onSelectTab(tab);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 backdrop-blur-xl bg-zinc-950/90 border-b border-zinc-800/80 w-full overflow-hidden">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand */}
        <button
          onClick={() => handleTabClick('upload')}
          className="flex items-center gap-2.5 group text-left transition-transform active:scale-95 flex-shrink-0"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 via-violet-500 to-cyan-400 p-0.5 shadow-lg shadow-indigo-500/20 group-hover:shadow-indigo-500/40 transition-shadow">
            <div className="w-full h-full bg-zinc-950 rounded-[10px] flex items-center justify-center">
              <CloudUpload className="w-4 h-4 text-indigo-400 group-hover:scale-110 transition-transform" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-base sm:text-lg tracking-tight bg-gradient-to-r from-white via-zinc-200 to-zinc-400 bg-clip-text text-transparent">
                ImgVault
              </span>
              <span className="text-[9px] sm:text-[10px] font-semibold tracking-wider uppercase px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                ImgBB
              </span>
            </div>
          </div>
        </button>

        {/* Desktop Navigation Tabs (Hidden on Mobile) */}
        <nav className="hidden md:flex items-center gap-1 lg:gap-2">
          <button
            onClick={() => handleTabClick('upload')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
              currentTab === 'upload'
                ? 'bg-zinc-800 text-white shadow-inner'
                : 'text-zinc-400 hover:text-white hover:bg-zinc-900/60'
            }`}
          >
            <CloudUpload className="w-4 h-4 text-indigo-400" />
            <span>Upload</span>
          </button>

          {user && (
            <button
              onClick={() => handleTabClick('dashboard')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                currentTab === 'dashboard'
                  ? 'bg-zinc-800 text-white shadow-inner'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-900/60'
              }`}
            >
              <LayoutDashboard className="w-4 h-4 text-violet-400" />
              <span>Dashboard</span>
            </button>
          )}

          <button
            onClick={() => handleTabClick('api')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
              currentTab === 'api'
                ? 'bg-zinc-800 text-white shadow-inner'
                : 'text-zinc-400 hover:text-white hover:bg-zinc-900/60'
            }`}
          >
            <Code2 className="w-4 h-4 text-cyan-400" />
            <span>API Docs</span>
          </button>

          <button
            onClick={() => handleTabClick('guide')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
              currentTab === 'guide'
                ? 'bg-zinc-800 text-white shadow-inner'
                : 'text-zinc-400 hover:text-white hover:bg-zinc-900/60'
            }`}
          >
            <Server className="w-4 h-4 text-emerald-400" />
            <span>Free Hosting Guide</span>
          </button>
        </nav>

        {/* Desktop User / Auth Actions */}
        <div className="hidden md:flex items-center gap-2.5">
          {user ? (
            <div className="flex items-center gap-2">
              {/* API Key Quick Copy Pill */}
              <button
                onClick={handleCopyKey}
                title="Click to copy your unique API key"
                className="hidden lg:flex items-center gap-2 px-2.5 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs font-mono text-zinc-300 transition-colors"
              >
                <Key className="w-3.5 h-3.5 text-amber-400" />
                <span>{user.apiKey.substring(0, 12)}...</span>
                {copiedKey ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5 text-zinc-500 hover:text-zinc-300" />
                )}
              </button>

              {/* User Avatar */}
              <button
                onClick={() => handleTabClick('dashboard')}
                className="flex items-center gap-2 px-2.5 py-1 rounded-lg bg-zinc-900 border border-zinc-800 hover:border-zinc-700 text-xs text-zinc-300 transition-colors"
              >
                <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-violet-600 to-indigo-500 flex items-center justify-center font-bold text-white text-[11px]">
                  {user.name.charAt(0).toUpperCase()}
                </div>
                <span className="font-medium max-w-[100px] truncate">{user.name}</span>
              </button>

              <button
                onClick={onLogout}
                title="Sign out"
                className="p-2 rounded-lg text-zinc-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                aria-label="Sign out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onOpenAuth('login')}
                className="px-3.5 py-1.5 rounded-lg text-xs font-medium text-zinc-300 hover:text-white hover:bg-zinc-800/80 transition-all"
              >
                Sign In
              </button>
              <button
                onClick={() => onOpenAuth('register')}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-indigo-500 via-violet-600 to-indigo-600 text-white shadow-md shadow-indigo-600/30 hover:shadow-indigo-600/50 hover:brightness-110 active:scale-95 transition-all"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Create Account</span>
              </button>
            </div>
          )}
        </div>

        {/* Mobile Controls (Menu Toggle & Quick Action) */}
        <div className="flex md:hidden items-center gap-2">
          {user ? (
            <button
              onClick={() => handleTabClick('dashboard')}
              className="flex items-center gap-1.5 p-1 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-zinc-300"
            >
              <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-violet-600 to-indigo-500 flex items-center justify-center font-bold text-white text-[10px]">
                {user.name.charAt(0).toUpperCase()}
              </div>
            </button>
          ) : (
            <button
              onClick={() => onOpenAuth('login')}
              className="px-2.5 py-1 rounded-lg text-xs font-medium text-zinc-300 hover:bg-zinc-800"
            >
              Sign In
            </button>
          )}

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-800 transition-colors"
            aria-label={mobileMenuOpen ? 'Close mobile menu' : 'Open mobile menu'}
          >
            {mobileMenuOpen ? <X className="w-5 h-5 text-indigo-400" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Dropdown Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-zinc-800/80 bg-zinc-950/98 px-4 py-4 space-y-2 animate-in slide-in-from-top-2 duration-150">
          <button
            onClick={() => handleTabClick('upload')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
              currentTab === 'upload'
                ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
                : 'text-zinc-300 hover:bg-zinc-900'
            }`}
          >
            <CloudUpload className="w-4 h-4 text-indigo-400" />
            <span>Upload Image</span>
          </button>

          {user && (
            <button
              onClick={() => handleTabClick('dashboard')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                currentTab === 'dashboard'
                  ? 'bg-violet-600/20 text-violet-300 border border-violet-500/30'
                  : 'text-zinc-300 hover:bg-zinc-900'
              }`}
            >
              <LayoutDashboard className="w-4 h-4 text-violet-400" />
              <span>Dashboard &amp; Gallery</span>
            </button>
          )}

          <button
            onClick={() => handleTabClick('api')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
              currentTab === 'api'
                ? 'bg-cyan-600/20 text-cyan-300 border border-cyan-500/30'
                : 'text-zinc-300 hover:bg-zinc-900'
            }`}
          >
            <Code2 className="w-4 h-4 text-cyan-400" />
            <span>ImgBB API v1 Docs</span>
          </button>

          <button
            onClick={() => handleTabClick('guide')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
              currentTab === 'guide'
                ? 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/30'
                : 'text-zinc-300 hover:bg-zinc-900'
            }`}
          >
            <Server className="w-4 h-4 text-emerald-400" />
            <span>Free Hosting Guide</span>
          </button>

          {/* User API Key & Auth in Mobile Menu */}
          <div className="pt-3 border-t border-zinc-800/80 space-y-2">
            {user ? (
              <>
                <div className="p-2.5 rounded-xl bg-zinc-900/80 border border-zinc-800 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-mono text-zinc-300 truncate mr-2">
                    <Key className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                    <span className="truncate">{user.apiKey.substring(0, 16)}...</span>
                  </div>
                  <button
                    onClick={handleCopyKey}
                    className="px-2 py-1 rounded bg-zinc-800 text-[11px] font-semibold text-zinc-200 hover:text-white"
                  >
                    {copiedKey ? 'Copied' : 'Copy'}
                  </button>
                </div>

                <button
                  onClick={() => {
                    onLogout();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full flex items-center justify-center gap-2 py-2 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-300 text-xs font-semibold"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out</span>
                </button>
              </>
            ) : (
              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={() => {
                    onOpenAuth('login');
                    setMobileMenuOpen(false);
                  }}
                  className="py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs font-medium text-zinc-200"
                >
                  Sign In
                </button>
                <button
                  onClick={() => {
                    onOpenAuth('register');
                    setMobileMenuOpen(false);
                  }}
                  className="py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-600 text-white text-xs font-semibold"
                >
                  Create Account
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
