import React, { useState, useEffect } from 'react';
import { User, ImageRecord, ImgBBApiResponse } from '../types/index.ts';
import { api } from '../services/api.ts';
import { formatBytes } from '../utils/formatters.ts';
import { 
  Key, 
  Copy, 
  Check, 
  RefreshCw, 
  Eye, 
  EyeOff, 
  Download, 
  Search, 
  Trash2, 
  ExternalLink, 
  Code, 
  HardDrive, 
  ImageIcon, 
  Layers, 
  Sparkles,
  AlertTriangle,
  UploadCloud,
  FileDown
} from 'lucide-react';

import { copyToClipboard } from '../utils/clipboard.ts';

interface DashboardProps {
  user: User;
  onSelectImage: (imageId: string) => void;
  onOpenEmbedModal: (imageData: ImgBBApiResponse['data']) => void;
  onSelectTab: (tab: 'upload' | 'dashboard' | 'api' | 'guide') => void;
  onUserUpdate: (updatedUser: User) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  user,
  onSelectImage,
  onOpenEmbedModal,
  onSelectTab,
  onUserUpdate,
}) => {
  const [images, setImages] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('newest');
  const [showKey, setShowKey] = useState(false);
  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedItemId, setCopiedItemId] = useState<string | null>(null);
  const [isRegenerating, setIsRegenerating] = useState(false);
  const [showRegenConfirm, setShowRegenConfirm] = useState(false);
  const [deleteIdConfirm, setDeleteIdConfirm] = useState<string | null>(null);

  // Fetch images
  const loadImages = async () => {
    setIsLoading(true);
    try {
      const data = await api.getImages({ scope: 'user', q: searchQuery, sort: sortBy });
      setImages(data);
    } catch (err) {
      console.error('Failed to load user images', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadImages();
  }, [searchQuery, sortBy]);

  // Copy API key
  const handleCopyApiKey = async () => {
    await copyToClipboard(user.apiKey);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  // Regenerate API key
  const handleRegenerateKey = async () => {
    setIsRegenerating(true);
    try {
      const newKey = await api.regenerateApiKey();
      onUserUpdate({ ...user, apiKey: newKey });
      setShowRegenConfirm(false);
    } catch (err) {
      console.error('Failed to regenerate key', err);
    } finally {
      setIsRegenerating(false);
    }
  };

  // Download ShareX custom uploader configuration file (.sxcu)
  const handleDownloadShareXConfig = () => {
    const origin = window.location.origin;
    const sharexConfig = {
      Version: '15.0.0',
      Name: `ImgVault (${user.name})`,
      DestinationType: 'ImageUploader',
      RequestMethod: 'POST',
      RequestURL: `${origin}/api/1/upload`,
      Headers: {
        'X-API-Key': user.apiKey,
      },
      Body: 'MultipartFormData',
      FileFormName: 'image',
      URL: '$json:data.url$',
      ThumbnailURL: '$json:data.thumb.url$',
      DeletionURL: '$json:data.delete_url$',
      ErrorMessage: '$json:error.message$',
    };

    const blob = new Blob([JSON.stringify(sharexConfig, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ImgVault-${user.name.replace(/\s+/g, '_')}.sxcu`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Copy quick direct link
  const handleCopyDirectLink = async (url: string, id: string) => {
    await copyToClipboard(url);
    setCopiedItemId(id);
    setTimeout(() => setCopiedItemId(null), 2000);
  };

  // Delete image
  const handleDeleteImage = async (id: string) => {
    try {
      await api.deleteImage(id);
      setImages((prev) => prev.filter((img) => img.id !== id));
      setDeleteIdConfirm(null);
      // Update local storage stats
      const deletedImg = images.find((i) => i.id === id);
      if (deletedImg) {
        onUserUpdate({
          ...user,
          uploadCount: Math.max(0, user.uploadCount - 1),
          storageUsedBytes: Math.max(0, user.storageUsedBytes - deletedImg.sizeBytes),
        });
      }
    } catch (err: any) {
      console.error('Failed to delete image:', err);
    }
  };

  const totalViews = images.reduce((acc, curr) => acc + (curr.views || 0), 0);
  const freeStorageQuotaBytes = 5 * 1024 * 1024 * 1024; // 5 GB standard free tier
  const storagePercentage = Math.min(100, Math.round((user.storageUsedBytes / freeStorageQuotaBytes) * 100));

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Welcome Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl bg-gradient-to-r from-zinc-900 via-zinc-900/90 to-zinc-950 border border-zinc-800 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-black text-white">
              Welcome back, {user.name}
            </h1>
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
              Free Tier Active
            </span>
          </div>
          <p className="text-zinc-400 text-sm">
            Manage your unique API key, browse hosted media, and inspect direct CDN embeds.
          </p>
        </div>

        <button
          onClick={() => onSelectTab('upload')}
          className="flex-shrink-0 px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-400 hover:to-violet-500 text-white font-semibold text-sm shadow-lg shadow-indigo-600/25 active:scale-95 transition-all flex items-center justify-center gap-2"
        >
          <UploadCloud className="w-4 h-4" />
          <span>Upload New Image</span>
        </button>
      </div>

      {/* API Key Card */}
      <div className="relative rounded-2xl bg-zinc-900/80 border border-zinc-800 p-6 shadow-xl backdrop-blur-sm overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 flex-shrink-0">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Your Personal API Key
              </h2>
              <p className="text-xs text-zinc-400">
                Use this unique token to upload images programmatically via cURL, Python, or ShareX.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadShareXConfig}
              className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium transition-colors flex items-center gap-1.5"
              title="Download ShareX uploader config file"
            >
              <FileDown className="w-3.5 h-3.5 text-cyan-400" />
              <span>ShareX Config (.sxcu)</span>
            </button>

            <button
              onClick={() => setShowRegenConfirm(true)}
              disabled={isRegenerating}
              className="px-3 py-1.5 rounded-lg border border-zinc-700 hover:border-zinc-600 text-zinc-400 hover:text-white text-xs font-medium transition-colors flex items-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRegenerating ? 'animate-spin' : ''}`} />
              <span>Regenerate Key</span>
            </button>
          </div>
        </div>

        {/* API Key Display Box */}
        <div className="flex flex-col sm:flex-row items-center gap-2 p-2 rounded-xl bg-zinc-950 border border-zinc-800 font-mono text-xs">
          <div className="flex-1 w-full px-3 py-2 text-zinc-300 truncate select-all">
            {showKey ? user.apiKey : `${user.apiKey.substring(0, 10)}••••••••••••••••••••••••••••••••`}
          </div>

          <div className="flex items-center gap-1.5 w-full sm:w-auto justify-end">
            <button
              onClick={() => setShowKey(!showKey)}
              className="p-2 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
              title={showKey ? 'Hide Key' : 'Reveal Key'}
            >
              {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4 text-zinc-400" />}
            </button>

            <button
              onClick={handleCopyApiKey}
              className={`px-3.5 py-1.5 rounded-lg font-semibold text-xs transition-all flex items-center gap-1.5 ${
                copiedKey
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white'
              }`}
            >
              {copiedKey ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Key</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Regenerate Confirmation Warning */}
        {showRegenConfirm && (
          <div className="mt-4 p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />
              <span>
                Regenerating your key will invalidate the current key immediately. Any scripts or uploaders using it must be updated.
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowRegenConfirm(false)}
                className="px-3 py-1 rounded bg-zinc-800 text-zinc-300 hover:bg-zinc-700"
              >
                Cancel
              </button>
              <button
                onClick={handleRegenerateKey}
                disabled={isRegenerating}
                className="px-3 py-1 rounded bg-amber-600 hover:bg-amber-500 text-white font-semibold"
              >
                Confirm &amp; Regenerate
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Stats Tiles */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800">
          <div className="flex items-center justify-between text-zinc-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">Total Images</span>
            <ImageIcon className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-black text-white">{user.uploadCount}</div>
          <p className="text-[11px] text-zinc-400 mt-1">Hosted across your account</p>
        </div>

        <div className="p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800">
          <div className="flex items-center justify-between text-zinc-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">Direct Views</span>
            <Eye className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-black text-white">{totalViews.toLocaleString()}</div>
          <p className="text-[11px] text-zinc-400 mt-1">CDN bandwidth hits</p>
        </div>

        <div className="p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800">
          <div className="flex items-center justify-between text-zinc-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">Storage Consumed</span>
            <HardDrive className="w-4 h-4 text-violet-400" />
          </div>
          <div className="text-2xl font-black text-white">{formatBytes(user.storageUsedBytes)}</div>
          <div className="w-full h-1.5 rounded-full bg-zinc-800 mt-2 overflow-hidden">
            <div
              className="h-full bg-violet-500 rounded-full"
              style={{ width: `${Math.max(4, storagePercentage)}%` }}
            />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800">
          <div className="flex items-center justify-between text-zinc-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">API Status</span>
            <Sparkles className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-400">Ready</div>
          <p className="text-[11px] text-zinc-400 mt-1">POST /api/1/upload active</p>
        </div>
      </div>

      {/* Image Gallery Section */}
      <div className="space-y-4">
        {/* Controls */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
            <input
              type="text"
              placeholder="Search images by name or title..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-sm text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          <div className="flex items-center gap-2">
            <label className="text-xs text-zinc-400">Sort by:</label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs font-medium text-zinc-300 focus:outline-none focus:border-indigo-500"
            >
              <option value="newest">Newest First</option>
              <option value="oldest">Oldest First</option>
              <option value="views">Most Views</option>
              <option value="size">Largest Size</option>
            </select>
          </div>
        </div>

        {/* Gallery Grid */}
        {isLoading ? (
          <div className="py-20 text-center text-zinc-500 text-sm">
            <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-indigo-400" />
            Loading your images...
          </div>
        ) : images.length === 0 ? (
          <div className="py-20 text-center rounded-2xl border border-dashed border-zinc-800 p-8">
            <ImageIcon className="w-12 h-12 text-zinc-600 mx-auto mb-3" />
            <h3 className="text-base font-bold text-white mb-1">No images found</h3>
            <p className="text-xs text-zinc-400 mb-5 max-w-sm mx-auto">
              {searchQuery ? 'Try adjusting your search filter.' : "You haven't uploaded any images to your account yet."}
            </p>
            <button
              onClick={() => onSelectTab('upload')}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/30"
            >
              Upload Image Now
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {images.map((img) => (
              <div
                key={img.id}
                className="group relative rounded-xl bg-zinc-900/70 border border-zinc-800 hover:border-zinc-700 overflow-hidden transition-all flex flex-col"
              >
                {/* Thumbnail */}
                <div
                  onClick={() => onSelectImage(img.id)}
                  className="relative aspect-video bg-zinc-950 flex items-center justify-center overflow-hidden cursor-pointer"
                >
                  <img
                    src={img.directUrl}
                    alt={img.title}
                    className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <span className="px-3 py-1.5 rounded-lg bg-black/80 text-white text-xs font-medium flex items-center gap-1.5 backdrop-blur-sm">
                      <Eye className="w-3.5 h-3.5" />
                      <span>Inspect Details</span>
                    </span>
                  </div>
                </div>

                {/* Details */}
                <div className="p-3.5 flex-1 flex flex-col justify-between">
                  <div>
                    <h4 className="font-semibold text-white text-sm truncate" title={img.title}>
                      {img.title || img.filename}
                    </h4>
                    <div className="flex items-center justify-between text-[11px] text-zinc-400 mt-1">
                      <span>{formatBytes(img.sizeBytes)}</span>
                      <span>{img.views} views</span>
                    </div>
                  </div>

                  {/* Actions Bar */}
                  <div className="flex items-center justify-between pt-3 mt-2 border-t border-zinc-800/80 gap-1">
                    <button
                      onClick={() => handleCopyDirectLink(img.directUrl, img.id)}
                      className="px-2 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[11px] font-medium transition-colors flex items-center gap-1"
                      title="Copy direct URL"
                    >
                      {copiedItemId === img.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-400">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Link</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={() => {
                        onOpenEmbedModal({
                          id: img.id,
                          title: img.title,
                          url_viewer: img.viewerUrl,
                          url: img.directUrl,
                          display_url: img.directUrl,
                          size: img.sizeBytes,
                          time: '0',
                          expiration: '0',
                          image: {
                            filename: img.filename,
                            name: img.title,
                            mime: img.mimeType,
                            extension: img.filename.split('.').pop() || 'png',
                            url: img.directUrl,
                          },
                          delete_url: '',
                        });
                      }}
                      className="px-2 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[11px] font-medium transition-colors flex items-center gap-1"
                      title="Get embed codes (BBCode, HTML, Markdown)"
                    >
                      <Code className="w-3 h-3 text-indigo-400" />
                      <span>Embed</span>
                    </button>

                    <button
                      onClick={() => setDeleteIdConfirm(img.id)}
                      className="p-1 rounded text-zinc-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                      title="Delete image"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Delete Confirmation Overlay */}
                {deleteIdConfirm === img.id && (
                  <div className="absolute inset-0 bg-zinc-950/95 backdrop-blur-sm p-4 flex flex-col items-center justify-center text-center z-10 animate-in fade-in">
                    <AlertTriangle className="w-6 h-6 text-rose-500 mb-2" />
                    <p className="text-xs font-semibold text-white mb-1">Delete image?</p>
                    <p className="text-[11px] text-zinc-400 mb-3">
                      This removes the file permanently from CDN.
                    </p>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setDeleteIdConfirm(null)}
                        className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-xs text-zinc-300"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => handleDeleteImage(img.id)}
                        className="px-2.5 py-1 rounded bg-rose-600 hover:bg-rose-500 text-xs text-white font-semibold"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
