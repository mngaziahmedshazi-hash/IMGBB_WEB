/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { User, ImgBBApiResponse } from './types/index.ts';
import { api } from './services/api.ts';
import { Navbar } from './components/Navbar.tsx';
import { UploadZone } from './components/UploadZone.tsx';
import { UploadResultModal } from './components/UploadResultModal.tsx';
import { Dashboard } from './components/Dashboard.tsx';
import { ImageViewer } from './components/ImageViewer.tsx';
import { ApiDocs } from './components/ApiDocs.tsx';
import { HostingGuideModal } from './components/HostingGuideModal.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { 
  CloudUpload, 
  ShieldCheck, 
  Zap, 
  Terminal, 
  Server, 
  Github, 
  CheckCircle2,
  ExternalLink
} from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'upload' | 'dashboard' | 'api' | 'guide'>('upload');
  const [user, setUser] = useState<User | null>(null);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register' | null>(null);
  const [activeUploadResult, setActiveUploadResult] = useState<ImgBBApiResponse['data'] | null>(null);
  const [viewingImageId, setViewingImageId] = useState<string | null>(null);
  const [storageConfig, setStorageConfig] = useState<any | null>(null);

  // Check URL path on mount (e.g., if someone opened /view/:id)
  useEffect(() => {
    const path = window.location.pathname;
    const match = path.match(/^\/view\/([a-zA-Z0-9_-]+)/);
    if (match && match[1]) {
      setViewingImageId(match[1]);
    }
  }, []);

  // Check initial user authentication
  useEffect(() => {
    async function initAuth() {
      const currentUser = await api.getCurrentUser();
      if (currentUser) {
        setUser(currentUser);
      }
      const cfg = await api.getStorageConfig();
      if (cfg) {
        setStorageConfig(cfg);
      }
    }
    initAuth();
  }, []);

  const handleLogout = () => {
    api.logout();
    setUser(null);
    if (currentTab === 'dashboard') {
      setCurrentTab('upload');
    }
  };

  const handleUploadSuccess = (result: ImgBBApiResponse['data']) => {
    setActiveUploadResult(result);
    // Refresh user stats if logged in
    api.getCurrentUser().then((u) => {
      if (u) setUser(u);
    });
  };

  const handleTabChange = (tab: 'upload' | 'dashboard' | 'api' | 'guide') => {
    setViewingImageId(null);
    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-indigo-500/30 selection:text-white">
      {/* Navigation Bar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={handleTabChange}
        user={user}
        onOpenAuth={(mode) => setAuthModalMode(mode)}
        onLogout={handleLogout}
      />

      {/* Main View Area */}
      <main className="flex-1 pb-16">
        {viewingImageId ? (
          <ImageViewer
            imageId={viewingImageId}
            onBack={() => setViewingImageId(null)}
          />
        ) : currentTab === 'upload' ? (
          <UploadZone
            user={user}
            onUploadSuccess={handleUploadSuccess}
            onOpenAuth={(mode) => setAuthModalMode(mode)}
            onSelectTab={setCurrentTab}
          />
        ) : currentTab === 'dashboard' && user ? (
          <Dashboard
            user={user}
            onSelectImage={(id) => setViewingImageId(id)}
            onOpenEmbedModal={(data) => setActiveUploadResult(data)}
            onSelectTab={setCurrentTab}
            onUserUpdate={(u) => setUser(u)}
          />
        ) : currentTab === 'api' ? (
          <ApiDocs
            user={user}
            onOpenAuth={(mode) => setAuthModalMode(mode)}
          />
        ) : currentTab === 'guide' ? (
          <HostingGuideModal />
        ) : (
          /* Fallback if user tab requested without login */
          <div className="max-w-md mx-auto py-24 px-4 text-center">
            <h3 className="text-lg font-bold text-white mb-2">Sign In Required</h3>
            <p className="text-xs text-zinc-400 mb-6">
              Please sign in or register to access your personal dashboard and unique API key.
            </p>
            <button
              onClick={() => setAuthModalMode('login')}
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-lg shadow-indigo-600/30"
            >
              Sign In to Your Account
            </button>
          </div>
        )}
      </main>

      {/* Upload Complete Modal */}
      {activeUploadResult && (
        <UploadResultModal
          uploadData={activeUploadResult}
          onClose={() => setActiveUploadResult(null)}
          onUploadAnother={() => {
            setActiveUploadResult(null);
            setCurrentTab('upload');
            setViewingImageId(null);
          }}
        />
      )}

      {/* Auth Modal (Login / Register) */}
      {authModalMode && (
        <AuthModal
          initialMode={authModalMode}
          onClose={() => setAuthModalMode(null)}
          onSuccess={(loggedInUser) => {
            setUser(loggedInUser);
            setCurrentTab('dashboard');
          }}
        />
      )}

      {/* Footer */}
      <footer className="border-t border-zinc-850 bg-zinc-950/90 py-8 px-4 sm:px-6 lg:px-8 text-xs text-zinc-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 font-bold text-white">
              <CloudUpload className="w-4 h-4 text-indigo-400" />
              <span>ImgVault</span>
            </div>
            <span>•</span>
            <span>Free Image Hosting &amp; ImgBB v1 API Compatible</span>
          </div>

          <div className="flex items-center gap-4 text-zinc-400">
            {storageConfig && (
              <span className="flex items-center gap-1.5 text-zinc-400 font-mono text-[11px]">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>{storageConfig.storageMode}</span>
              </span>
            )}
            <button
              onClick={() => handleTabChange('guide')}
              className="hover:text-zinc-200 transition-colors"
            >
              Free Hosting Setup
            </button>
            <button
              onClick={() => handleTabChange('api')}
              className="hover:text-zinc-200 transition-colors"
            >
              API Reference
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
