import express, { Request, Response, NextFunction } from 'express';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import multer from 'multer';
import { createServer as createViteServer } from 'vite';
import { generateApiKey, validateApiKey, isExpired, calculateExpiryDate } from './src/utils/formatters.ts';
import { User, ImageRecord, ImgBBApiResponse } from './src/types/index.ts';

const uploadMiddleware = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 32 * 1024 * 1024 }, // 32MB max
});

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = parseInt(process.env.PORT || '3000', 10);
const isProd = process.env.NODE_ENV === 'production';

// Persistent storage directories for free hosting / local dev
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

if (!fs.existsSync(DATA_DIR)) {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  } catch (err) {
    console.warn('Could not create data directory, using in-memory only', err);
  }
}

// In-Memory Database with optional disk persistence
interface DBState {
  users: Record<string, User & { passwordHash: string; salt: string }>;
  images: Record<string, ImageRecord>;
}

// Password hashing helper
function hashPassword(password: string, salt: string): string {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

// Seed initial demo user
const demoSalt = 'imgvault_demo_salt_2026';
const initialUsers: Record<string, User & { passwordHash: string; salt: string }> = {
  'usr_demo_123': {
    id: 'usr_demo_123',
    email: 'demo@imgvault.dev',
    name: 'Demo Creator',
    apiKey: 'iv_live_demo887766554433221100aabbccddee',
    createdAt: new Date(Date.now() - 7 * 86400000).toISOString(),
    storageUsedBytes: 2450000,
    uploadCount: 3,
    passwordHash: hashPassword('password123', demoSalt),
    salt: demoSalt,
    role: 'user',
  },
};

// Seed sample demo images for nice first-paint experience
const rawSvgText1 = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="600" viewBox="0 0 800 600"><defs><linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#6366f1"/><stop offset="50%" stop-color="#8b5cf6"/><stop offset="100%" stop-color="#d946ef"/></linearGradient></defs><rect width="800" height="600" fill="url(#g)"/><circle cx="400" cy="280" r="120" fill="rgba(255,255,255,0.15)"/><text x="400" y="300" font-family="system-ui,sans-serif" font-size="36" font-weight="bold" fill="white" text-anchor="middle">ImgVault Cloud</text><text x="400" y="340" font-family="system-ui,sans-serif" font-size="18" fill="rgba(255,255,255,0.85)" text-anchor="middle">Sample High Resolution Asset</text></svg>`;
const rawSvgText2 = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="600" viewBox="0 0 800 600"><defs><linearGradient id="g2" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#0f172a"/><stop offset="100%" stop-color="#064e3b"/></linearGradient></defs><rect width="800" height="600" fill="url(#g2)"/><polygon points="400,160 520,380 280,380" fill="#10b981" opacity="0.8"/><text x="400" y="440" font-family="system-ui,sans-serif" font-size="28" font-weight="bold" fill="white" text-anchor="middle">Direct CDN Embed Ready</text></svg>`;
const sampleSvg1 = `data:image/svg+xml;base64,${Buffer.from(rawSvgText1).toString('base64')}`;
const sampleSvg2 = `data:image/svg+xml;base64,${Buffer.from(rawSvgText2).toString('base64')}`;

const initialImages: Record<string, ImageRecord> = {
  'demo-cdn-hero': {
    id: 'demo-cdn-hero',
    title: 'Neon Gradient Horizon',
    filename: 'neon-gradient.svg',
    mimeType: 'image/svg+xml',
    sizeBytes: 1024 * 780,
    width: 800,
    height: 600,
    createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
    expiresAt: null,
    views: 142,
    userId: 'usr_demo_123',
    userEmail: 'demo@imgvault.dev',
    dataUrl: sampleSvg1,
    deleteToken: 'del_demo_token_1',
  },
  'demo-vector-badge': {
    id: 'demo-vector-badge',
    title: 'Emerald Polygon Art',
    filename: 'emerald-art.svg',
    mimeType: 'image/svg+xml',
    sizeBytes: 1024 * 512,
    width: 800,
    height: 600,
    createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
    expiresAt: null,
    views: 89,
    userId: 'usr_demo_123',
    userEmail: 'demo@imgvault.dev',
    dataUrl: sampleSvg2,
    deleteToken: 'del_demo_token_2',
  },
};

let db: DBState = {
  users: { ...initialUsers },
  images: { ...initialImages },
};

// Load saved DB if exists
if (fs.existsSync(DB_FILE)) {
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    if (parsed && parsed.users && parsed.images) {
      db = {
        users: { ...initialUsers, ...parsed.users },
        images: { ...initialImages, ...parsed.images },
      };
    }
  } catch (err) {
    console.warn('Could not read existing db.json, using fresh state', err);
  }
}

function saveDB() {
  try {
    if (fs.existsSync(DATA_DIR)) {
      fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
    }
  } catch (err) {
    console.warn('Failed to persist DB to disk', err);
  }
}

// Session store (token -> userId)
const sessions = new Map<string, string>();
// Add persistent session for demo user
sessions.set('demo_session_token_123', 'usr_demo_123');

// Express App
async function startServer() {
  const app = express();

  // Middleware: Increased body size limit for image uploads (base64 strings up to 50MB)
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // CORS headers
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization, X-API-Key');
    if (req.method === 'OPTIONS') {
      res.sendStatus(200);
      return;
    }
    next();
  });

  // Auth helper
  function getUserFromRequest(req: Request): User | null {
    // 1. Try Bearer token
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7).trim();
      const userId = sessions.get(token);
      if (userId && db.users[userId]) {
        const u = db.users[userId];
        return {
          id: u.id,
          email: u.email,
          name: u.name,
          apiKey: u.apiKey,
          createdAt: u.createdAt,
          storageUsedBytes: u.storageUsedBytes,
          uploadCount: u.uploadCount,
          role: u.role,
        };
      }
    }

    // 2. Try API Key header or query
    const apiKey = (req.headers['x-api-key'] || req.query.key || (req.body && req.body.key)) as string | undefined;
    if (apiKey) {
      const foundUser = Object.values(db.users).find((u) => u.apiKey === apiKey);
      if (foundUser) {
        return {
          id: foundUser.id,
          email: foundUser.email,
          name: foundUser.name,
          apiKey: foundUser.apiKey,
          createdAt: foundUser.createdAt,
          storageUsedBytes: foundUser.storageUsedBytes,
          uploadCount: foundUser.uploadCount,
          role: foundUser.role,
        };
      }
    }

    return null;
  }

  // Base URL helper
  function getBaseUrl(req: Request): string {
    const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'http';
    const host = req.headers['x-forwarded-host'] || req.headers.host || `localhost:${PORT}`;
    return `${protocol}://${host}`;
  }

  // ==========================================
  // DIRECT IMAGE SERVING: /i/:id and /i/:id.:ext
  // ==========================================
  app.get('/i/:id', (req: Request, res: Response) => {
    let idParam = req.params.id;
    // Strip file extension if present (e.g., /i/abc1234.png -> abc1234)
    const dotIndex = idParam.indexOf('.');
    const imageId = dotIndex > -1 ? idParam.substring(0, dotIndex) : idParam;

    const img = db.images[imageId];
    if (!img) {
      res.status(404).send('Image not found or has been deleted.');
      return;
    }

    // Check expiration
    if (isExpired(img.expiresAt)) {
      delete db.images[imageId];
      saveDB();
      res.status(410).send('This image has expired and is no longer available.');
      return;
    }

    // Increment views
    img.views += 1;
    saveDB();

    // 1. If external storageUrl, redirect directly (e.g. Cloudinary CDN)
    if (img.storageUrl && img.storageUrl.startsWith('http')) {
      res.redirect(img.storageUrl);
      return;
    }

    // Serve from dataUrl
    if (!img.dataUrl) {
      res.status(404).send('Image payload missing.');
      return;
    }

    // 2. If dataUrl is a remote URL
    if (img.dataUrl.startsWith('http://') || img.dataUrl.startsWith('https://')) {
      res.redirect(img.dataUrl);
      return;
    }

    try {
      // 3. Robust Base64 extraction (never fails on dots, dashes, spaces or newlines)
      const commaIndex = img.dataUrl.indexOf(',');
      if (commaIndex !== -1) {
        const header = img.dataUrl.substring(0, commaIndex);
        const rawBase64 = img.dataUrl.substring(commaIndex + 1).replace(/\s/g, '');
        const mimeMatch = header.match(/^data:([^;]+);base64/i);
        const mime = mimeMatch ? mimeMatch[1] : (img.mimeType || 'image/png');
        const buffer = Buffer.from(rawBase64, 'base64');
        res.setHeader('Content-Type', mime);
        res.setHeader('Content-Length', buffer.length);
        res.setHeader('Cache-Control', img.expiresAt ? 'no-cache' : 'public, max-age=31536000');
        res.send(buffer);
        return;
      }

      // 4. Raw SVG text
      if (img.dataUrl.startsWith('data:image/svg+xml') || img.dataUrl.startsWith('<svg')) {
        const prefix = 'data:image/svg+xml;utf8,';
        let svgContent = img.dataUrl.startsWith(prefix) ? img.dataUrl.slice(prefix.length) : img.dataUrl;
        try {
          svgContent = decodeURIComponent(svgContent);
        } catch {
          // keep original if decoding fails
        }
        res.setHeader('Content-Type', 'image/svg+xml; charset=utf-8');
        res.send(svgContent);
        return;
      }

      res.status(500).send('Invalid image representation.');
    } catch (err: any) {
      console.error('Error serving image:', err);
      res.status(500).send('Failed to serve image.');
    }
  });

  // ==========================================
  // AUTH ROUTES
  // ==========================================
  app.post('/api/auth/register', (req: Request, res: Response) => {
    const { email, password, name } = req.body;
    if (!email || !password || !name) {
      res.status(400).json({ error: 'Please provide email, password, and name.' });
      return;
    }
    if (password.length < 6) {
      res.status(400).json({ error: 'Password must be at least 6 characters.' });
      return;
    }

    const normalizedEmail = String(email).trim().toLowerCase();
    const existing = Object.values(db.users).find((u) => u.email.toLowerCase() === normalizedEmail);
    if (existing) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const salt = crypto.randomBytes(16).toString('hex');
    const passwordHash = hashPassword(password, salt);
    const userId = `usr_${crypto.randomBytes(8).toString('hex')}`;
    const apiKey = generateApiKey();

    const newUser: User & { passwordHash: string; salt: string } = {
      id: userId,
      email: normalizedEmail,
      name: String(name).trim(),
      apiKey,
      createdAt: new Date().toISOString(),
      storageUsedBytes: 0,
      uploadCount: 0,
      passwordHash,
      salt,
      role: 'user',
    };

    db.users[userId] = newUser;
    saveDB();

    const token = `tok_${crypto.randomBytes(24).toString('hex')}`;
    sessions.set(token, userId);

    const safeUser: User = {
      id: newUser.id,
      email: newUser.email,
      name: newUser.name,
      apiKey: newUser.apiKey,
      createdAt: newUser.createdAt,
      storageUsedBytes: newUser.storageUsedBytes,
      uploadCount: newUser.uploadCount,
      role: newUser.role,
    };

    res.status(201).json({ user: safeUser, token });
  });

  app.post('/api/auth/login', (req: Request, res: Response) => {
    const { email, password } = req.body;
    if (!email || !password) {
      res.status(400).json({ error: 'Email and password are required.' });
      return;
    }

    const normalizedEmail = String(email).trim().toLowerCase();
    const user = Object.values(db.users).find((u) => u.email.toLowerCase() === normalizedEmail);

    if (!user) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    const computedHash = hashPassword(password, user.salt);
    if (computedHash !== user.passwordHash) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    const token = `tok_${crypto.randomBytes(24).toString('hex')}`;
    sessions.set(token, user.id);

    const safeUser: User = {
      id: user.id,
      email: user.email,
      name: user.name,
      apiKey: user.apiKey,
      createdAt: user.createdAt,
      storageUsedBytes: user.storageUsedBytes,
      uploadCount: user.uploadCount,
      role: user.role,
    };

    res.json({ user: safeUser, token });
  });

  app.get('/api/auth/me', (req: Request, res: Response) => {
    const user = getUserFromRequest(req);
    if (!user) {
      res.status(401).json({ error: 'Not authenticated' });
      return;
    }
    res.json({ user });
  });

  app.post('/api/auth/regenerate-key', (req: Request, res: Response) => {
    const currentUser = getUserFromRequest(req);
    if (!currentUser) {
      res.status(401).json({ error: 'Authentication required' });
      return;
    }

    const newKey = generateApiKey();
    if (db.users[currentUser.id]) {
      db.users[currentUser.id].apiKey = newKey;
      saveDB();
    }

    res.json({ apiKey: newKey, message: 'New API key generated successfully.' });
  });

  // ==========================================
  // IMGBB COMPATIBLE UPLOAD API: POST /api/1/upload
  // Also supports /1/upload for drop-in compatibility
  // ==========================================
  const handleUpload = async (req: Request, res: Response) => {
    try {
      // API Key check (optional for web upload, required for external API callers)
      const providedKey = (req.query.key || req.headers['x-api-key'] || req.body.key) as string | undefined;
      let associatedUser: User | null = getUserFromRequest(req);

      if (providedKey && !associatedUser) {
        const found = Object.values(db.users).find((u) => u.apiKey === providedKey);
        if (found) {
          associatedUser = found;
        } else {
          // Invalid API key provided
          res.status(400).json({
            status_code: 400,
            error: {
              message: 'Invalid API key. Please check your account dashboard for the active key.',
              code: 100,
            },
            status_txt: 'Bad Request',
          });
          return;
        }
      }

      // Read image data: can be base64 string in req.body.image, or direct URL
      let dataUrl = '';
      let mimeType = 'image/png';
      let extension = 'png';
      let sizeBytes = 0;
      let originalFilename = '';

      // Check if file uploaded via multipart form-data (cURL, ShareX, HTML Form)
      if (req.file) {
        mimeType = req.file.mimetype || 'image/png';
        sizeBytes = req.file.size;
        dataUrl = `data:${mimeType};base64,${req.file.buffer.toString('base64')}`;
        originalFilename = req.file.originalname || '';
        const extMatch = originalFilename.match(/\.([a-zA-Z0-9]+)$/);
        if (extMatch) extension = extMatch[1].toLowerCase();
      } else {
        // Read image data from body (base64 string or remote image URL)
        let rawImage = req.body?.image;
        if (!rawImage && typeof req.body === 'string') {
          try {
            const parsed = JSON.parse(req.body);
            rawImage = parsed.image;
          } catch {
            // ignore
          }
        }

        if (!rawImage) {
          res.status(400).json({
            status_code: 400,
            error: {
              message: 'No image data provided. Provide a file, base64 encoded image string, or image URL in the "image" field.',
              code: 101,
            },
            status_txt: 'Bad Request',
          });
          return;
        }

        dataUrl = String(rawImage).trim();

        // Format normalize: If raw base64 or raw SVG without data: prefix
        if (!dataUrl.startsWith('data:') && !dataUrl.startsWith('http')) {
          if (dataUrl.startsWith('<svg') || dataUrl.startsWith('<?xml')) {
            mimeType = 'image/svg+xml';
            extension = 'svg';
            dataUrl = `data:image/svg+xml;base64,${Buffer.from(dataUrl).toString('base64')}`;
          } else if (dataUrl.startsWith('/9j/')) {
            mimeType = 'image/jpeg';
            extension = 'jpg';
            dataUrl = `data:${mimeType};base64,${dataUrl}`;
          } else if (dataUrl.startsWith('R0lGOD')) {
            mimeType = 'image/gif';
            extension = 'gif';
            dataUrl = `data:${mimeType};base64,${dataUrl}`;
          } else if (dataUrl.startsWith('UklGR')) {
            mimeType = 'image/webp';
            extension = 'webp';
            dataUrl = `data:${mimeType};base64,${dataUrl}`;
          } else {
            // Default to PNG base64
            dataUrl = `data:${mimeType};base64,${dataUrl}`;
          }
        } else if (dataUrl.startsWith('data:')) {
          const mimeMatch = dataUrl.match(/^data:([a-zA-Z0-9/+-]+);/);
          if (mimeMatch) {
            mimeType = mimeMatch[1];
            if (mimeType.includes('jpeg')) extension = 'jpg';
            else if (mimeType.includes('png')) extension = 'png';
            else if (mimeType.includes('webp')) extension = 'webp';
            else if (mimeType.includes('gif')) extension = 'gif';
            else if (mimeType.includes('svg')) extension = 'svg';
          }
        }

        // Calculate size
        if (dataUrl.startsWith('data:')) {
          const commaIdx = dataUrl.indexOf(',');
          const base64Part = commaIdx !== -1 ? dataUrl.substring(commaIdx + 1) : '';
          sizeBytes = Math.round((base64Part.length * 3) / 4);
        } else {
          sizeBytes = 150000;
        }
      }

      // Title & filename
      const customName = req.body?.name || req.body?.title || (originalFilename ? originalFilename.replace(/\.[^/.]+$/, '') : '');
      const imageId = crypto.randomBytes(5).toString('hex'); // 10 chars unique ImgBB-style ID
      const baseFilename = customName ? `${customName.replace(/[^a-zA-Z0-9-_]/g, '_')}` : `img_${imageId}`;
      const filename = baseFilename.endsWith(`.${extension}`) ? baseFilename : `${baseFilename}.${extension}`;
      const title = customName || baseFilename;

      // Expiration (safe parse)
      const expirationSeconds = Math.max(0, parseInt(String(req.body?.expiration || req.query?.expiration || 0), 10) || 0);
      const expiresAt = calculateExpiryDate(expirationSeconds);

      // Create record
      const deleteToken = crypto.randomBytes(16).toString('hex');
      const newImage: ImageRecord = {
        id: imageId,
        title,
        filename,
        mimeType,
        sizeBytes,
        createdAt: new Date().toISOString(),
        expiresAt,
        views: 0,
        userId: associatedUser ? associatedUser.id : null,
        userEmail: associatedUser ? associatedUser.email : undefined,
        dataUrl,
        deleteToken,
      };

      db.images[imageId] = newImage;

      // Update user stats if associated
      if (associatedUser && db.users[associatedUser.id]) {
        db.users[associatedUser.id].uploadCount = (db.users[associatedUser.id].uploadCount || 0) + 1;
        db.users[associatedUser.id].storageUsedBytes = (db.users[associatedUser.id].storageUsedBytes || 0) + sizeBytes;
      }

      saveDB();

      const baseUrl = getBaseUrl(req);
      const directUrl = `${baseUrl}/i/${imageId}.${extension}`;
      const viewerUrl = `${baseUrl}/view/${imageId}`;
      const deleteUrl = `${baseUrl}/api/images/${imageId}/delete?token=${deleteToken}`;

      // Standard ImgBB Response JSON
      const responsePayload: ImgBBApiResponse = {
        data: {
          id: imageId,
          title,
          url_viewer: viewerUrl,
          url: directUrl,
          display_url: directUrl,
          size: sizeBytes,
          time: Math.floor(Date.now() / 1000).toString(),
          expiration: expirationSeconds.toString(),
          image: {
            filename,
            name: baseFilename,
            mime: mimeType,
            extension,
            url: directUrl,
          },
          thumb: {
            url: directUrl,
          },
          delete_url: deleteUrl,
        },
        success: true,
        status: 200,
      };

      res.status(200).json(responsePayload);
    } catch (err: any) {
      console.error('Upload handler error:', err);
      res.status(500).json({
        status_code: 500,
        error: {
          message: err.message || 'Failed to process image upload.',
        },
        success: false,
      });
    }
  };

  app.post('/api/1/upload', uploadMiddleware.single('image'), handleUpload);
  app.post('/1/upload', uploadMiddleware.single('image'), handleUpload);

  // ==========================================
  // IMAGE GALLERY & MANAGEMENT API
  // ==========================================
  app.get('/api/images', (req: Request, res: Response) => {
    const user = getUserFromRequest(req);
    const scope = req.query.scope as string | undefined;

    // Filter images
    let imagesList = Object.values(db.images);

    // Filter out expired
    imagesList = imagesList.filter((img) => !isExpired(img.expiresAt));

    // If requested user images only
    if (user && scope !== 'public') {
      imagesList = imagesList.filter((img) => img.userId === user.id);
    } else if (!user && scope !== 'public') {
      // Guest: return empty or public preview
      imagesList = imagesList.filter((img) => img.userId === null);
    }

    // Search query
    const q = (req.query.q as string || '').toLowerCase().trim();
    if (q) {
      imagesList = imagesList.filter((img) =>
        img.title.toLowerCase().includes(q) || img.filename.toLowerCase().includes(q)
      );
    }

    // Sorting
    const sort = (req.query.sort as string) || 'newest';
    imagesList.sort((a, b) => {
      if (sort === 'oldest') return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      if (sort === 'views') return b.views - a.views;
      if (sort === 'size') return b.sizeBytes - a.sizeBytes;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(); // newest
    });

    // Strip bulky dataUrl from listing for fast response, provide preview thumbnail
    const sanitized = imagesList.map((img) => {
      const baseUrl = getBaseUrl(req);
      const ext = img.filename.split('.').pop() || 'png';
      return {
        id: img.id,
        title: img.title,
        filename: img.filename,
        mimeType: img.mimeType,
        sizeBytes: img.sizeBytes,
        createdAt: img.createdAt,
        expiresAt: img.expiresAt,
        views: img.views,
        userId: img.userId,
        directUrl: `${baseUrl}/i/${img.id}.${ext}`,
        viewerUrl: `${baseUrl}/view/${img.id}`,
      };
    });

    res.json({ images: sanitized });
  });

  app.get('/api/images/:id', (req: Request, res: Response) => {
    const img = db.images[req.params.id];
    if (!img || isExpired(img.expiresAt)) {
      res.status(404).json({ error: 'Image not found or expired.' });
      return;
    }

    const baseUrl = getBaseUrl(req);
    const ext = img.filename.split('.').pop() || 'png';

    res.json({
      image: {
        id: img.id,
        title: img.title,
        filename: img.filename,
        mimeType: img.mimeType,
        sizeBytes: img.sizeBytes,
        createdAt: img.createdAt,
        expiresAt: img.expiresAt,
        views: img.views,
        userId: img.userId,
        directUrl: `${baseUrl}/i/${img.id}.${ext}`,
        viewerUrl: `${baseUrl}/view/${img.id}`,
        previewUrl: `${baseUrl}/i/${img.id}.${ext}`,
      },
    });
  });

  // Delete image
  app.delete('/api/images/:id', (req: Request, res: Response) => {
    const id = req.params.id;
    const img = db.images[id];
    if (!img) {
      res.status(404).json({ error: 'Image not found.' });
      return;
    }

    const user = getUserFromRequest(req);
    const deleteToken = (req.query.token || req.headers['x-delete-token']) as string | undefined;

    const isOwner = user && img.userId === user.id;
    const hasValidToken = deleteToken && img.deleteToken === deleteToken;

    if (!isOwner && !hasValidToken) {
      res.status(403).json({ error: 'You are not authorized to delete this image.' });
      return;
    }

    // Decrement user stats
    if (img.userId && db.users[img.userId]) {
      db.users[img.userId].uploadCount = Math.max(0, db.users[img.userId].uploadCount - 1);
      db.users[img.userId].storageUsedBytes = Math.max(0, db.users[img.userId].storageUsedBytes - img.sizeBytes);
    }

    delete db.images[id];
    saveDB();

    res.json({ success: true, message: 'Image successfully deleted.' });
  });

  // Delete link handler (for delete_url direct click)
  app.get('/api/images/:id/delete', (req: Request, res: Response) => {
    const id = req.params.id;
    const img = db.images[id];
    const token = req.query.token as string | undefined;

    if (img && token && img.deleteToken === token) {
      if (img.userId && db.users[img.userId]) {
        db.users[img.userId].uploadCount = Math.max(0, db.users[img.userId].uploadCount - 1);
        db.users[img.userId].storageUsedBytes = Math.max(0, db.users[img.userId].storageUsedBytes - img.sizeBytes);
      }
      delete db.images[id];
      saveDB();
      res.send(`<!DOCTYPE html><html><body style="background:#09090b;color:#f4f4f5;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;"><div style="text-align:center;padding:2rem;background:#18181b;border-radius:12px;border:1px solid #27272a;"><h2>Image Deleted</h2><p style="color:#a1a1aa">The image was permanently deleted from ImgVault servers.</p><a href="/" style="color:#6366f1;text-decoration:none;">&larr; Return to Homepage</a></div></body></html>`);
      return;
    }

    res.status(403).send('Invalid or expired deletion token.');
  });

  // Storage info & provider status endpoint
  app.get('/api/config/providers', (req: Request, res: Response) => {
    const hasCloudinary = Boolean(process.env.CLOUDINARY_URL || (process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY));
    const hasFirebase = Boolean(process.env.FIREBASE_STORAGE_BUCKET);
    const hasMongo = Boolean(process.env.MONGODB_URI);

    res.json({
      storageMode: hasCloudinary ? 'Cloudinary CDN (Cloud)' : hasFirebase ? 'Firebase Storage (Cloud)' : 'ImgVault Core Store (Zero-Config Active)',
      cloudStorageEnabled: hasCloudinary || hasFirebase,
      databaseMode: hasMongo ? 'MongoDB Atlas (Persistent)' : 'ImgVault File/Memory DB (Active)',
      maxUploadSizeMB: 32,
      supportedMimeTypes: ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml'],
    });
  });

  // ==========================================
  // VITE DEV MIDDLEWARE / STATIC ASSETS
  // ==========================================
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`> ImgVault Server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
